import { Stack, StackProps } from 'aws-cdk-lib';
import { Construct } from 'constructs';
import * as lambda_ from 'aws-cdk-lib/aws-lambda';
// import * as sqs from 'aws-cdk-lib/aws-sqs';

export class Sprint1TsStack extends Stack {
  constructor(scope: Construct, id: string, props?: StackProps) {
    super(scope, id, props);

    // The code that defines your stack goes here

    // example resource
    // const queue = new sqs.Queue(this, 'Sprint1TsQueue', {
    //   visibilityTimeout: cdk.Duration.seconds(300)
    // });
    
    const HWL=this.createLambda('Saqib_HW_Lambda','./resources','HWL.handler')
  }
  
  
  
  createLambda(id:string, path:string, handler:string) {
    return new lambda_.Function(this,'My Function',
    {
      
      runtime:lambda_.Runtime.NODEJS_12_X,
      handler:handler,
      code:lambda_.Code.fromAsset(path),
      
    });
   
    
  };
  
  
  
}
