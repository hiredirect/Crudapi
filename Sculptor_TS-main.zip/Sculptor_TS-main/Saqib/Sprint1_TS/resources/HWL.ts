exports.handler = async function(event:any){
    return ('Hello Sprint 1 in TyoeScript')
}