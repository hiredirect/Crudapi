// constants file
export const METRIC_NAMESPACE = "mkhanURLNameSpace";
export const METRICNAME_AVAILABLITY = "Url_Availablity"
export const METRICNAME_LATENCY = "Url_latency"