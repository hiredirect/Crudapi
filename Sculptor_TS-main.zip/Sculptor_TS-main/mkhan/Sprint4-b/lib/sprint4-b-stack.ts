import { Duration, RemovalPolicy, Stack, StackProps } from 'aws-cdk-lib';
import { Construct } from 'constructs';
import * as lambda_ from 'aws-cdk-lib/aws-lambda';
import * as apigateway from 'aws-cdk-lib/aws-apigateway';
import { ManagedPolicy, Role, ServicePrincipal } from 'aws-cdk-lib/aws-iam';
import { Rule, Schedule } from 'aws-cdk-lib/aws-events';
import * as targets from 'aws-cdk-lib/aws-events-targets';
// import * as sqs from 'aws-cdk-lib/aws-sqs';

export class Sprint4BStack extends Stack {
  constructor(scope: Construct, id: string, props?: StackProps) {
    super(scope, id, props);
    
    //creating layer for lambda function
    const layer = this.createLayer();
    //creating lambda role
    const role = this.createRole();

    // creating the WebHealthlambda function
    const WebHealthLambda = this.createLambda('WHLambda', './resources/api_backend', 'WHLambda.lambda_handler', role, layer)
    //removal policy destroy so when cdk destroy the resource also get destroyed
    WebHealthLambda.applyRemovalPolicy(RemovalPolicy.DESTROY);
    
    //generating event
    const eventLambda = Schedule.rate(Duration.hours(1));
    //genrating target
    const WHTargetLambda = new targets.LambdaFunction(WebHealthLambda);
    //rule to connect event to target
    const ruleLambda = new Rule(this, 'LambdaInvocationRule', {
      description: "Invoke lambda after 1 hour",
      schedule: eventLambda,
      targets: [WHTargetLambda],
    });

    //creating lambda for REST
    const lambdaApi = this.createLambda('ApiLambda','./resources/api_backend','LambdaApi.lambda_handler', role, layer);
    //Using API Gateway for lambda
    const api = new apigateway.LambdaRestApi(this, 'mkhan-Api', {
      handler: lambdaApi
    });
  }

  createLambda(id:string,asset:string,handler:string,role:any,layer:any){
    // allocating resources to lambda
    return new lambda_.Function(this, id,
      {code: lambda_.Code.fromAsset(asset),
      handler: handler,
      runtime: lambda_.Runtime.NODEJS_14_X,
      timeout:Duration.seconds(30),
      role:role,
      layers:[layer]}
      );
  }
  // layer creation
  createLayer(){
    return new lambda_.LayerVersion(this, 'ApiLayer', {
      removalPolicy: RemovalPolicy.DESTROY,
      code: lambda_.Code.fromAsset("layers"),
    });
  }
  // role creation
  createRole(){
    return new Role(this, "lambdaRole", {
      assumedBy: new ServicePrincipal('lambda.amazonaws.com'),
      managedPolicies: [
        ManagedPolicy.fromAwsManagedPolicyName('service-role/AWSLambdaBasicExecutionRole'),
        ManagedPolicy.fromAwsManagedPolicyName('AmazonAPIGatewayInvokeFullAccess'),
        ManagedPolicy.fromAwsManagedPolicyName('cloudWatchFullAccess')
      ]
    });
  }
}