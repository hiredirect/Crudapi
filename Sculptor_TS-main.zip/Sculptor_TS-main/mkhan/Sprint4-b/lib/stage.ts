import { Stage, StackProps } from 'aws-cdk-lib';
import { Construct } from 'constructs';
import { Sprint4BStack } from './sprint4-b-stack';
// import * as sqs from 'aws-cdk-lib/aws-sqs';

export class mkhanStage extends Stage {
    constructor(scope: Construct, id: string, props?: StackProps) {
        super(scope, id, props);
        //instantiating the Express application
        const stage = new Sprint4BStack(this, "API-Application")

    }
}