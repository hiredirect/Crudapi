import { Stack, StackProps, pipelines, SecretValue, aws_codepipeline_actions as actions } from 'aws-cdk-lib';
import { ManualApprovalStep } from 'aws-cdk-lib/pipelines';
import { Construct } from 'constructs';
import { mkhanStage } from './stage';
// import * as sqs from 'aws-cdk-lib/aws-sqs';

export class pipelineStack extends Stack {
    constructor(scope: Construct, id: string, props?: StackProps) {
        super(scope, id, props);

        //defining pipeline source 
        const source = pipelines.CodePipelineSource.gitHub('muhammadsculptor2022skipq/Sculptor_TS', 'main', {
            authentication: SecretValue.secretsManager('my_token'),
            trigger: actions.GitHubTrigger.POLL
        })
        //defining shellstep for the build
        const synth = new pipelines.ShellStep("mkhan-Synth", {
            input: source,
            commands: [
                'cd mkhan/Sprint4-b/',
                'npm ci', 
                'npm run build', 
                'cd layer/nodejs',
                'npm install axios',
                'npm install express',
                'npm install mongodb',
                'npm install @vendia/serverless-express',
                'cd ../..',
                'npx cdk synth'
            ],
            primaryOutputDirectory: 'mkhan/Sprint4-b/cdk.out',
        });
        //creating pipeline
        const myPipeline = new pipelines.CodePipeline(this, "mkhan-API-Pipeline", {
            synth: synth
        });
        //creating stages
        const betaStage = new mkhanStage(this, "mkhan-Beta");
        const prodStage = new mkhanStage(this, "mkhan-Prod");
        //adding stages to pipeline
        myPipeline.addStage(betaStage);
        myPipeline.addStage(prodStage);
    }
}