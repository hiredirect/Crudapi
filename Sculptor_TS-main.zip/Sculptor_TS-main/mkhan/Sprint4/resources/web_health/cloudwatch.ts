const AWS=require('aws-sdk');


export class CloudWatchPublishData{
 
    publish_data(namespace:string, metric_name:string,dimensions:any, metric_value:any){
      /** This function publishes data to cloudwatch
        Args:
          namespace: str- namespace
          metricName: str- metric name
          dimensions: array - url and name
          metric_value: number - value of metric 
          
     **/
        var cloudwatch= new AWS.CloudWatch();
        var params = {
            MetricData: [ 
              {
                'MetricName': metric_name,
                'Dimensions': dimensions,
                'Value': metric_value,
              },
            ],
            Namespace: namespace 
          };

          cloudwatch.putMetricData(params, function(err:any, data:any) {
            if (err) console.log(err, err.stack); // an error occurred
            else     console.log(data);           // successful response
          });
        }
    AvailAlarm(metric_name: string, url: string, namespace:string) {
        const cw = new AWS.CloudWatch();
    
          var params = {
                AlarmName: `mkhanAlarm_${metric_name}_${url}`,
                ComparisonOperator: 'LessThanThreshold',
                EvaluationPeriods: 1,
                MetricName: metric_name + url,
                Period: 10,
                Threshold: 1,
                Statistic: 'Average',
                Namespace: namespace,
                //AlarmDescription: '',
            };
            cw.putMetricAlarm(params, function (err: any, data: any) {
                if (err) {
                    console.log("Error", err);
                } else {
                    console.log("Success", data);
                }
            });
        }
        //function to create a latency alarm for each url
        LatencyAlarm(metric_name: string, url: string, namespace:string) {
            const cw = new AWS.CloudWatch();
    
            var params = {
                AlarmName: `mkhanAlarm_${metric_name}_${url}`,
                ComparisonOperator: 'GreaterThanThreshold',
                EvaluationPeriods: 1,
                MetricName: metric_name + url,
                Period: 10,
                Threshold: 130,
                Statistic: 'Average',
                Namespace: namespace
                //AlarmDescription: '',
            };
            cw.putMetricAlarm(params, function (err: any, data: any) {
                if (err) {
                    console.log("Error", err);
                } else {
                    console.log("Success", data);
                }
            });
  
        
    }
    }