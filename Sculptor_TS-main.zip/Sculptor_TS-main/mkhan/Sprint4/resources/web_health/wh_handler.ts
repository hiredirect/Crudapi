const axios = require("axios");
import { url } from "inspector";
import * as constant from "./constant"
import { CloudWatchPublishData } from "./cloudwatch"
const bodyParser = require('body-parser');
const { MongoClient, ServerApiVersion } = require('mongodb');
const { dbget } = require('./api-backend/mongodb_facade');


exports.handler = async (event:any) => {

    let cw = new CloudWatchPublishData();
    let values = [];
    let avail, lat;
    let urls = await dbget();

    for(let i=0;i<urls.length;i++){

        avail = await getAvailability(urls[i].url);
        lat = await getLatency(urls[i].url);
        values.push({
            "url:": urls[i].url,
            "Availibality":avail,
            "Latency":lat 
        });
        let dimensions=[
            {'Name':'URL','Value':urls[i].url}
        ]
        // pasing data to publish metrics to cloudwatch
       cw.publish_data(constant.METRIC_NAME_AVAILIBALITY, urls[i].url, dimensions, avail)
       cw.publish_data(constant.METRIC_NAME_LATENCY, urls[i].url, dimensions, lat)

       cw.AvailAlarm(constant.METRIC_NAME_AVAILIBALITY, urls[i].url, constant.NAMESPACE)
       cw.LatencyAlarm(constant.METRIC_NAME_LATENCY, urls[i].url, constant.NAMESPACE)
    }    

    return values;

}

async function getAvailability (urls:string) {

    const avail = await axios.get(urls);
    if(avail.status == 200){
        return 1.0;
    }else{
        return 0.0;
    }
}

async function getLatency (urls:string) {

    let startTime = new Date().getTime();
    const lat = await axios.get(urls);
    let endTime = new Date().getTime();
    let delta = endTime - startTime;
    return delta;
}