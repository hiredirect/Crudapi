//express: a library help us to write on the server

const express = require('express'); //import express from 'express'
const bodyparser = require('body-parser');
const {dbget, dbcreate, dbdelete, dbupdate} = require('./mongodb_facade')
//import {dbget} from './mongodb_facade'

const {deleteAlarm} = require('./deletealarm')
export const app = express()   //app: a method to write all http method
app.use(bodyparser.json()) // whenever a app recieve a request convert it into json formate

app.listen(3000, function(){  //initialize the express app
  console.log('Listening at the port 3000')
})

// get method
app.get('/', (req : any, res : any) => {
    /*
    1st parameter: path - root
    2nd parameter: request u get
    3rd parameter: response
    */
  //res.send('hello world! it is our local server');
  dbget().then((results : any)=> {
    if(results=='No URL exist'){
      res.send("URL does not exist.");
  }
  else{
      
    res.json({'statusCode': 200,
              'body': results
              });
}});
})

//post method
app.post('/', (req : any, res : any) => {
  console.log(req.body)
  dbcreate(req.body).then((results : any) =>{
    if(results=='URL already exist'){
      res.send("URL already exist.");
  }
  else{
    res.send('URL added')  
  }
  })
})

//delete method
app.delete('/', (req : any, res : any) => {
  console.log(req.body)
  const delreq = req.body.url
  deleteAlarm(delreq)
  
  //dbdelete(req.body).then((results : any) =>{
  //  res.send('URL deleted')
  dbdelete(delreq).then((results : any) =>{
    if(results=='does not exist'){
      res.send("URL does not exist.");
  }
  else{
    res.send('URL deleted')  
  }
})
})

 //put method-update
app.put('/', (req : any, res : any) => {
  console.log(req.body)
  dbupdate(req.body).then((results : any) =>{
    if(results=='does not exist'){
      res.send("URL does not exist.");
  }
  else{
    res.send('URL updated')  
  }
  })
})

//module.exports = app;