const { MongoClient, ServerApiVersion } = require('mongodb');

import {
    aws_cloudwatch as cw, 
    aws_cloudwatch_actions as cwActions 
  } from 'aws-cdk-lib';

export async function dbget (){ 
    const uri = "mongodb+srv://mkhan:skipq@cluster0.iruqgtr.mongodb.net/?retryWrites=true&w=majority";
    //const client = new MongoClient(uri, { useNewUrlParser: true, useUnifiedTopology: true, serverApi: ServerApiVersion.v1 });
    const client = new MongoClient(uri);

    try {
        await client.connect();
        //checking if the URL already exists
        const results = await client.db('Webhealth').collection('urls').find({}).toArray();
        if(results.length==0){
            return "No URL exist";
        }
        return results;
    }finally{
    await client.close();
    }

}

export async function dbcreate (newURL: any){ 
    const uri = "mongodb+srv://mkhan:skipq@cluster0.iruqgtr.mongodb.net/?retryWrites=true&w=majority";
    //const client = new MongoClient(uri, { useNewUrlParser: true, useUnifiedTopology: true, serverApi: ServerApiVersion.v1 });
   const client = new MongoClient(uri);

    try {
        await client.connect();
        //checking if the URL already exists
        const check = await client.db('webhealth').collection('url').find({"url":newURL}).toArray();
        if(check.length!=0){
            return "URL already exist";
        }
        const results = await client.db('Webhealth').collection('urls').insertOne(newURL);
        return results;
    }finally{
    await client.close();
    }

}
export async function dbdelete (newURL: any){ 
    const uri = "mongodb+srv://mkhan:skipq@cluster0.iruqgtr.mongodb.net/?retryWrites=true&w=majority";
    //const client = new MongoClient(uri, { useNewUrlParser: true, useUnifiedTopology: true, serverApi: ServerApiVersion.v1 });
    const client = new MongoClient(uri);

    try {
        await client.connect();
        //checking if the URL already exists
        const check = await client.db('webhealth').collection('url').find({"url":newURL}).toArray();
        if(check.length==0){
            return "does not exist";
        }
        const results = await client.db('Webhealth').collection('urls').deleteOne(newURL);
        return results;
    }finally{
    await client.close();
    }

}
export async function dbupdate (URL: any[]){ 
    const uri = "mongodb+srv://mkhan:skipq@cluster0.iruqgtr.mongodb.net/?retryWrites=true&w=majority";
    //const client = new MongoClient(uri, { useNewUrlParser: true, useUnifiedTopology: true, serverApi: ServerApiVersion.v1 });
    const client = new MongoClient(uri);

    try {
        await client.connect();
        //checking if the URL already exists
        const check = await client.db('webhealth').collection('url').find({"url":URL[0]}).toArray();
        if(check.length==0){
            return "does not exist";
        }
        const results = await client.db('Webhealth').collection('urls').updateOne({"url":URL[0]},{$set:{"url":URL[1]}});
        return results;
    }finally{
    await client.close();
    }

}


//module.exports.dbget = dbget;
//module.exports.dbcreate = dbcreate;
//module.exports.dbdelete = dbdelete;
//module.exports.dbupdate = dbupdate; 