

//delete alarm whenever a URL is deleted on our database
const AWS = require("aws-cdk")

export async function deletealarm (url: any){ 
    const cw = new AWS.cloudwatch();
    const param = {
        AlarmNames: [`mkhan-avail-alarm-${url}`,
        `mkhan-latency-alarm-${url}`]
    }
    
    cw.deleteAlarms(param,function(err:any, data:any)
       { if(err){
            console.log('Error : ', err);
        } else {
            console.log('Success : ',data);
        }
    
        })

}