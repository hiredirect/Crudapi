//forwarding the request get on lambda function to the server
require('source-map-support/register')
import serverlessExpress from '@vendia/serverless-express' //import library
import {app} from './server' 
exports.handler = serverlessExpress({app})

