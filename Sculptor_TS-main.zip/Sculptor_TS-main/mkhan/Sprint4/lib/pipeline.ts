import { Construct } from 'constructs';
import { Stack, 
    StackProps, 
    pipelines, 
    SecretValue, 
    aws_codepipeline_actions as actions 
    } from 'aws-cdk-lib';
import { ManualApprovalStep } from 'aws-cdk-lib/pipelines';
import * as lambda from 'aws-cdk-lib/aws-lambda';
import { MkhanStage } from './stage';

export class pipelineStack extends Stack {
    constructor(scope: Construct, id: string, props?: StackProps) {
        super(scope, id, props);
        
        //defining github source for pipeline
        const source = pipelines.CodePipelineSource.gitHub('muhammadsculptor2022skipq/Sculptor_TS', 'main', {
            authentication: SecretValue.secretsManager('my_token'),
            trigger: actions.GitHubTrigger.POLL
        })
        
        // build step
        const synth = new pipelines.ShellStep("MkhanSynth", {
            input: source,
            commands: ['cd mkhan/Sprint4/', 
            'npm ci', 
            'npm run build',
            'cd layer/nodejs',
             'npm install axios',
             'npm install mongodb',
             'npm i --save-dev@types/node',
             'npm install body-parser',
             'npm install express' ,'cd ../../', 'npx cdk synth'],
            primaryOutputDirectory: 'mkhan/Sprint4/cdk.out',
        });
        
        
        // adding unit tests
        const unitTest = new pipelines.ShellStep("UnitTest", {
            input: source,
            commands: ['cd mkhan/Sprint4-a/', 'npm ci', 'npm run test']
        })

        // create cdk pipeline
        const myPipeline = new pipelines.CodePipeline(this, "Mkhan-Sprint4-pipeline", {
            synth: synth
        });
        
        //creating stages for pipelines
        const betaStage = new MkhanStage(this, "betaStageMkhan");
        const gammaStage = new MkhanStage(this, "gammaStageMkhan");
        const prodStage = new MkhanStage(this, "prodStageMkhan");

        // Adding stages to pipeline
        myPipeline.addStage(betaStage, {pre: [unitTest]});
        myPipeline.addStage(gammaStage);
        myPipeline.addStage(prodStage,{ pre: [new ManualApprovalStep('mkhan Prod approval')]})
}}