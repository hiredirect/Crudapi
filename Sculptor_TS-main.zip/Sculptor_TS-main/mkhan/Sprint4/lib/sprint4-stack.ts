import { Construct } from 'constructs';
import * as lambda from 'aws-cdk-lib/aws-lambda'
import * as codedeploy from 'aws-cdk-lib/aws-codedeploy'
import  * as apigateway from 'aws-cdk-lib/aws-apigateway';
import { Schedule,
   Rule 
  } from 'aws-cdk-lib/aws-events'
import { Duration,
  Stack,
  StackProps, 
  RemovalPolicy, 
  aws_events_targets as targets, 
  aws_dynamodb as dynamodb, 
  aws_cloudwatch as cw, 
  aws_sns as sns, 
  aws_sns_subscriptions as subscriptions, 
  aws_cloudwatch_actions as cwActions 
} from 'aws-cdk-lib';

import { ManagedPolicy, 
  Role, 
  ServicePrincipal 
} from 'aws-cdk-lib/aws-iam';
import * as constant from "../resources/web_health/constant";

export class Sprint4Stack extends Stack {
  constructor(scope: Construct, id: string, props?: StackProps) {
    super(scope, id, props);
    
    //creating layer for lambda function
    const layer = new lambda.LayerVersion(this, 'MyLayer', {
      removalPolicy: RemovalPolicy.DESTROY,
      code: lambda.Code.fromAsset("layer"),
    });

    //creating lambda role
    const lambda_role = this.createLambdaRole();

    // creating the web_health_lambda function
    const web_health_lambda = this.createLambda('web_health_lambda', './resources/web_health', 'wh_handler.lambda_handler', layer, lambda_role)
    //removal policy destroy so when cdk destroy the resource also get destroyed
    web_health_lambda.applyRemovalPolicy(RemovalPolicy.DESTROY);

    //Lambda api gateway
    const lambda_api_backend = this.createLambda('lambda_api_backend',  './resources/api_backend','api_backend.handler', layer, lambda_role);
    //lambda_api_backend.applyRemovalPolicy(RemovalPolicy.DESTROY);

    const api = new apigateway.LambdaRestApi(this, 'mkhan-API', {handler:lambda_api_backend});

   

   //generating event
   const eventLambda = Schedule.rate(Duration.hours(1));
   //genrating target
   const WHTargetLambda = new targets.LambdaFunction(web_health_lambda);
   //rule to connect event to target
   const ruleLambda = new Rule(this, 'LambdaInvocationRule', {
     description: "Invoke lambda after 1 hour",
     schedule: eventLambda,
     targets: [WHTargetLambda],
   });


  }

  // creating lambda function 
  createLambda(id: string, path: string, handler: string, layer: any, role: any) {

    return new lambda.Function(this, id, {
      runtime: lambda.Runtime.NODEJS_12_X,
      handler: handler,
      code: lambda.Code.fromAsset(path),
      role: role,
      timeout: Duration.seconds(10),
      layers: [layer],


    });
  }


  // creating lambda role
  createLambdaRole() {
    return new Role(this, "lambdaRole", {
      assumedBy: new ServicePrincipal('lambda.amazonaws.com'),
      managedPolicies: [
      ManagedPolicy.fromAwsManagedPolicyName('service-role/AWSLambdaBasicExecutionRole'),
      ManagedPolicy.fromAwsManagedPolicyName('cloudWatchFullAccess'),
      ManagedPolicy.fromAwsManagedPolicyName('AmazonDynamoDBFullAccess'),
      ManagedPolicy.fromAwsManagedPolicyName('AmazonAPIGatewayInvokeFullAccess')
      ]


    })
  };

}

