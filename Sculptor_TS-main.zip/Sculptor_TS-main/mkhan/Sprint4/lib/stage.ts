import { Stack, 
    StackProps, 
    Stage 
} from 'aws-cdk-lib';
import { Construct } from 'constructs';
import {Sprint4Stack} from '../lib/sprint4-stack'

export class MkhanStage extends Stage {
    constructor(scope: Construct, id: string, props?: StackProps) {
      super(scope, id, props);
    
      const stage = new Sprint4Stack(this, "MkhanApplication")
    
    }
}
