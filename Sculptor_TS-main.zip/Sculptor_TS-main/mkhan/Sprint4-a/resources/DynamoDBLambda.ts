import { DynamoDBManipulateData } from "./DynamoDBManipulate";

exports.handler = async function (event: any) {
    /** Function which adds data to DB
     Args:
        event - contains SNS notification
    **/

    // parsing json file to retrieve information when alarm trigger
    const msgObj = JSON.parse(event.Records[0].Sns.Message);
   
    // extracting data
    const tableName = process.env.table; // accessing table name
    const url = msgObj.Trigger.Dimensions[0].value; // web resources which breaches threshold
    const nameSpace = msgObj.Trigger.Namespace; // namespace
    const msgId = event.Records[0].Sns.MessageId; // retrive msg id from event
    const metricName = msgObj.Trigger.MetricName; // metric name by which alarm trigger
    const threshold = msgObj.Trigger.Threshold; //threshold at which alarm trigger
    
    //creating instance of DynamoDMManiuplate data
    const dbTable = new DynamoDBManipulateData();
    if (event.Records) {
        const res = dbTable.addData(tableName, msgId,  metricName, nameSpace, url, threshold);
    }

}