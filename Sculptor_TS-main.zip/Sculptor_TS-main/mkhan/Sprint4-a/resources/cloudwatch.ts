const AWS=require('aws-sdk');


export class CloudWatchPublishData{
 
    publish_data(namespace:string, metric_name:string,dimensions:any, metric_value:any){
      /** This function publishes data to cloudwatch
        Args:
          namespace: str- namespace
          metricName: str- metric name
          dimensions: array - url and name
          metric_value: number - value of metric 
          
     **/
        var cloudwatch= new AWS.CloudWatch();
        var params = {
            MetricData: [ 
              {
                'MetricName': metric_name,
                'Dimensions': dimensions,
                'Value': metric_value,
              },
            ],
            Namespace: namespace 
          };

          cloudwatch.putMetricData(params, function(err:any, data:any) {
            if (err) console.log(err, err.stack); // an error occurred
            else     console.log(data);           // successful response
          });
         
        
    }
}