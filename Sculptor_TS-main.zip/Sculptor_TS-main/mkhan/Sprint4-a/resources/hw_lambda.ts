// lambda function
exports.handler = async function(event:any) {
    //hello world
    return (`hello ${event.firstname} ${event.lastname}`)
}