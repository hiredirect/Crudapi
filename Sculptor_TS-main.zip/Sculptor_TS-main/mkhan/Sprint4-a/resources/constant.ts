
export let URL_TO_MONITOR=['https://www.skipq.org/', 'https://www.google.com/', 'https://shaukatkhanum.org.pk/', 'https://leetcode.com/'];
export let NAMESPACE='MkhanNamespace'; //name space
export let METRIC_NAME_LATENCY="latency"; //latency metric name
export let METRIC_NAME_AVAILIBALITY="availibility";  // availability metric name



























export let CLOUDWATCH_POLICY='CloudWatchFullAccess';
export let EVALUATION_PERIOD=1;
// threshold for latecny
export let LATENCY_THRESHOLD=0.1;
// threshold fro avaialbility
export let AVAILIBILITY_THRESHOLD=1;