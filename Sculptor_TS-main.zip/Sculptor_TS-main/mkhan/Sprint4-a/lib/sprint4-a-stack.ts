import { Construct } from 'constructs';
import * as lambda from 'aws-cdk-lib/aws-lambda'
import * as codedeploy from 'aws-cdk-lib/aws-codedeploy'
import { Schedule,
   Rule 
  } from 'aws-cdk-lib/aws-events'
import { Duration,
  Stack,
  StackProps, 
  RemovalPolicy, 
  aws_events_targets as targets, 
  aws_dynamodb as dynamodb, 
  aws_cloudwatch as cw, 
  aws_sns as sns, 
  aws_sns_subscriptions as subscriptions, 
  aws_cloudwatch_actions as cwActions 
} from 'aws-cdk-lib';

import { ManagedPolicy, 
  Role, 
  ServicePrincipal 
} from 'aws-cdk-lib/aws-iam';
import * as constant from "../resources/constant";

export class Sprint4AStack extends Stack {
  constructor(scope: Construct, id: string, props?: StackProps) {
    super(scope, id, props);
    
    // arguments to pass to the WH_lambda function
    const lambda_id = "WH_Lambda";
    const lambda_path = "./resources";
    const lambda_handler = "WH_Lambda.handler";
    
    //creating layer for lambda function
    const layer = new lambda.LayerVersion(this, 'MyLayer', {
      removalPolicy: RemovalPolicy.DESTROY,
      code: lambda.Code.fromAsset("layer"),
    });

    //creating lambda role
    const lambda_role = this.createLambdaRole();

    // arguments to pass to the DB_lambda function
    const DBlambda_id = "Mkhan_DB_Lambda";
    const DBlambda_handler = "DB_Lambda.handler";

    // calling the WebHealthlambda function
    const WebHealthLambda = this.createLambda(lambda_id, lambda_path, lambda_handler, layer, lambda_role)
    //removal policy destroy so when cdk destroy the resource also get destroyed
    WebHealthLambda.applyRemovalPolicy(RemovalPolicy.DESTROY);

    // getting WebHealthLambda Crawler: Two metrics to keep track the health of services
    const duration_metric = WebHealthLambda.metricDuration();
    const errors_metric = WebHealthLambda.metricErrors();

    //creating alarms for these metrics
    const duration_alarm = new cw.Alarm(this, 'Duration_Alarm', {
      comparisonOperator: cw.ComparisonOperator.GREATER_THAN_THRESHOLD,
      threshold: 2000,
      evaluationPeriods: 1,
      metric: duration_metric
    });

    const errors_alarm = new cw.Alarm(this, 'Errors_Alarm', {
      comparisonOperator: cw.ComparisonOperator.GREATER_THAN_THRESHOLD,
      threshold: 1,
      evaluationPeriods: 1,
      metric: errors_metric
    });
    
    // calling the DBlambda function
    const DBLambda = this.createLambda(DBlambda_id, lambda_path, DBlambda_handler, layer, lambda_role)
    DBLambda.applyRemovalPolicy(RemovalPolicy.DESTROY);

    //creating topic and subscribing to it
    const topic = new sns.Topic(this, 'WHTopic');
    topic.applyRemovalPolicy(RemovalPolicy.DESTROY);
    topic.addSubscription(new subscriptions.EmailSubscription('muhammad.khan.skipq@gmail.com'))
    topic.addSubscription(new subscriptions.LambdaSubscription(DBLambda));

    //creating table and adding envoirment variable to DBLambda function
    const alarmTable = this.createTable();
    alarmTable.grantFullAccess(DBLambda);
    alarmTable.applyRemovalPolicy(RemovalPolicy.DESTROY);
    DBLambda.addEnvironment("TABLE_NAME", alarmTable.tableName)

    //Enabling automated rollback
    // https://docs.aws.amazon.com/cdk/api/v2/docs/aws-cdk-lib.aws_lambda.Alias.html
    const alias = new lambda.Alias(this, 'WH_Lambda_Alias', {
      aliasName: 'Prod',
      version: WebHealthLambda.currentVersion
    });

    new codedeploy.LambdaDeploymentGroup(this, 'BlueGreenDeployment', {
      alias: alias,
      deploymentConfig: codedeploy.LambdaDeploymentConfig.LINEAR_10PERCENT_EVERY_1MINUTE,
      alarms : [duration_alarm,errors_alarm]
    });


    //generating event
    const eventLambda = Schedule.rate(Duration.hours(1));
    //genrating target
    const WHTargetLambda = new targets.LambdaFunction(WebHealthLambda);
    //rule to connect event to target
    const ruleLambda = new Rule(this, 'LambdaInvocationRule', {
      description: "Invoke lambda after 1 hour",
      schedule: eventLambda,
      targets: [WHTargetLambda],
    });


    //creating cloudwatch metric
    for( let i=0; i<constant.URL_TO_MONITOR.length;i++){

      //creating availblity metric
      const availability_metric = new cw.Metric({
        metricName: constant.METRIC_NAME_AVAILIBALITY,
        namespace: constant.NAMESPACE,
        label: "Availability Metric",
        period: Duration.hours(1),
        dimensionsMap: { "url": constant.URL_TO_MONITOR[i] }
         });

      //creating latency metric
      const latency_metric = new cw.Metric({
        metricName: constant.METRIC_NAME_LATENCY,
        namespace: constant.NAMESPACE,
        label: "Latency Metric",
        period: Duration.hours(1),
        dimensionsMap: { "url": constant.URL_TO_MONITOR[i] }
        });

      // creating availblity and latency Alarms
      const latency_alarm = new cw.Alarm(this, `LatencyAlarm${constant.URL_TO_MONITOR[i]}`, {
        comparisonOperator: cw.ComparisonOperator.GREATER_THAN_THRESHOLD,
        threshold: 0.22,
        evaluationPeriods: 1,
        metric: latency_metric
       });

       const availability_alarm = new cw.Alarm(this, `AvailabilityAlarm${constant.URL_TO_MONITOR[i]}`, {
        comparisonOperator: cw.ComparisonOperator.LESS_THAN_THRESHOLD,
        threshold: 1,
        evaluationPeriods: 1,
        metric: availability_metric
        });

      //adding actions to alarm, send notification to lambda function when alarm is triggered
      latency_alarm.addAlarmAction(new cwActions.SnsAction(topic));
      latency_alarm.applyRemovalPolicy(RemovalPolicy.DESTROY);

      availability_alarm.addAlarmAction(new cwActions.SnsAction(topic));
      availability_alarm.applyRemovalPolicy(RemovalPolicy.DESTROY);

      
    }

  }


  // creating dynamodb table
  createTable() {
    return new dynamodb.Table(this, 'Mkhan-Table', {
      partitionKey: { name: 'id', type: dynamodb.AttributeType.STRING },
      billingMode : dynamodb.BillingMode.PAY_PER_REQUEST
    });
  }

  // creating lambda function 
  createLambda(id: string, path: string, handler: string, layer: any, role: any) {

    return new lambda.Function(this, id, {
      runtime: lambda.Runtime.NODEJS_12_X,
      handler: handler,
      code: lambda.Code.fromAsset(path),
      role: role,
      timeout: Duration.seconds(10),
      layers: [layer],


    });
  }


  // creating lambda role
  createLambdaRole() {
    return new Role(this, "lambdaRole", {
      assumedBy: new ServicePrincipal('lambda.amazonaws.com'),
      managedPolicies: [ManagedPolicy.fromAwsManagedPolicyName('service-role/AWSLambdaBasicExecutionRole'),
      ManagedPolicy.fromAwsManagedPolicyName('cloudWatchFullAccess'),
      ManagedPolicy.fromAwsManagedPolicyName('AmazonDynamoDBFullAccess')]


    })
  };

}

