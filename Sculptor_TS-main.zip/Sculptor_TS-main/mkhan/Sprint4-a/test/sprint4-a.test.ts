import * as cdk from 'aws-cdk-lib';
import { Template } from 'aws-cdk-lib/assertions';
import * as Sprint4A from '../lib/sprint4-a-stack';

// example test. To run these tests, uncomment this file along with the
// example resource in lib/sprint4-a-stack.ts
//test('SQS Queue Created', () => {
//   const app = new cdk.App();
//     // WHEN
//   const stack = new Sprint4A.Sprint4AStack(app, 'MyTestStack');
//     // THEN
//   const template = Template.fromStack(stack);

//   template.hasResourceProperties('AWS::SQS::Queue', {
//     VisibilityTimeout: 300
//   });
//});

test('Function to count Lambda function', () => {
    const app = new cdk.App();
      
    const stack = new Sprint4A.Sprint4AStack(app, 'LambdaCountTestStack');
      
    const template = Template.fromStack(stack);
  
    template.hasResource('AWS::Lambda::Function',1)
      });
    test('Function to SNS Subscription', () => {
      const app = new cdk.App();
        
      const stack = new Sprint4A.Sprint4AStack(app, 'SNSTestStack');
        
      const template = Template.fromStack(stack);
    
      template.findResources('AWS::Lambda::LayerVersion')
        });
    test("DynamoDB resources  test", () => {
      const app = new cdk.App();
      const stack = new Sprint4A.Sprint4AStack(app, 'DBTestStack');
      const template = Template.fromStack(stack);
      template.hasResourceProperties("AWS::DynamoDB::Table",{})
  
      });
    test("Function to count table", () => {
        const app = new cdk.App();
        const stack = new Sprint4A.Sprint4AStack(app, 'sprint3TestStack');
        const template = Template.fromStack(stack);
        template.resourceCountIs('AWS::DynamoDB::Table', 1);
    
      });
    
    
    test("Function to count alarm", () => {
        const app = new cdk.App();
        const stack = new Sprint4A.Sprint4AStack(app, 'sprint3TestStack');
        const template = Template.fromStack(stack);
        template.resourceCountIs('AWS::CloudWatch::Alarm', 10);
    
      });