# Sprint4-a: Convert Python Projects into JavaScript

In sprint 4 we have to convert all the previous sprints, sprint 1-2 and 3 into Java script. I have deployed the pipeline in Python. Now by converting all these sprints into JavaScript, I am able to continue my learning in sprint-4sprint-4, full stack development phase, of SkipQ.

## This project is divided into different parts:
1-Pointed app.py to pipelines.stack

2-Build step - Defined the source for build the project

3-Define the test for aws resources

4-Rollback-Point the alias to the current version of the application to smoothly rollback to previous version in case of error.

5- Add manual approval step before deployment

## Resources used:
Github: github repository is used as a source of code for our project

AWS Codepipeline: high-level construct library that makes it easy to set up a continuous deployment pipeline for your CDK applications, powered by AWS CodePipeline

AWS Cloudwatch: Collect, monitoring and operational data in form of logs, events, metrics and visualizes it using automated dashboad.

AWS Codebuild: fully managed continuous integration service that compiles source code, runs tests, and produces software packages that are ready to deploy.

AWS Codedeploy: Fully managed deployment service that automates software deployments to a variety of compute services such as Amazon EC2, AWS Fargate, AWS Lambda, and your on-premises servers.

AWS Lambda: serverless compute service that runs your code in response to events and automatically manages the underlying compute resources

AWS DynamoDB: Fully managed proprietary NoSQL database service that supports key–value and document data structures

The `cdk.json` file tells the CDK Toolkit how to execute your app.

## Useful commands

* `npm run build`   compile typescript to js
* `npm run watch`   watch for changes and compile
* `npm run test`    perform the jest unit tests
* `cdk deploy`      deploy this stack to your default AWS account/region
* `cdk diff`        compare deployed stack with current state
* `cdk synth`       emits the synthesized CloudFormation template
