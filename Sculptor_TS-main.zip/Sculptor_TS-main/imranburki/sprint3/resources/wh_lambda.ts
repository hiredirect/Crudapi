const axios=require('axios');
import {CloudWatchPublishData} from './cloudwatch_publishData';
import * as constants from './constants';


exports.handler= async function(event:any) {
    var resutl=[]
    let aval;
    let laten;
    var cloudwatch= new CloudWatchPublishData();
    
    for(let i=0;i< constants.URL_TO_MONITOR.length;i++){
        aval=await getAvailability(constants.URL_TO_MONITOR[i]);
        laten=await getLatency(constants.URL_TO_MONITOR[i]);
        resutl.push({
            "url:": constants.URL_TO_MONITOR[i],
            "Availibality":aval,
            "Latency":laten 
        });
        let dimensions=[
            {'Name':'URL','Value':constants.URL_TO_MONITOR[i]}
        ]
        
       cloudwatch.publish_data(constants.NAMESPACE,constants.METRIC_NAME_LATENCY,dimensions,laten)
       cloudwatch.publish_data(constants.NAMESPACE,constants.METRIC_NAME_AVAILIBALITY,dimensions,aval)
       console.log('in lambda function',aval)
    }

    //instatient the cloudwatchPublishData
    
     
    return resutl;
}

async function getLatency(url:string){
    try{
        let start_time=new Date().getTime();
    const latency= await axios.get(url);
    let end_time=new Date().getTime();
    let delta=end_time - start_time;
    return delta;
    }
    catch(error){
        return error;
    }
    
}

async function getAvailability(url:string){
    let res=0.0;
    try{
        let avail=await axios.get(url);
    if(avail.status== 200){
        res= 1.0
    }
    return res;
    }
    catch(error)
    {
        return 0.0
    }
}
