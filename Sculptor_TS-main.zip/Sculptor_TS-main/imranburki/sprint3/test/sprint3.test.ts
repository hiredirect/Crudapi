import * as cdk from 'aws-cdk-lib';
import { Template } from 'aws-cdk-lib/assertions';
import * as Sprint3 from '../lib/sprint3-stack';
import * as sqs from 'aws-cdk-lib/aws-sqs';
import * as sns from "aws-cdk-lib/aws-sns";

// example test. To run these tests, uncomment this file along with the
// example resource in lib/sprint3-stack.ts

// The AWS Typescript documentation link for creating test case
//https://docs.aws.amazon.com/cdk/v2/guide/testing.html

//https://docs.aws.amazon.com/cdk/api/v2/docs/aws-cdk-lib.assertions-readme.html
//test1
test('SQS Queue Created', () => {
  const app = new cdk.App();
    // WHEN
  const stack = new Sprint3.Sprint3Stack(app, 'MyTestStack');
    // THEN
  const template = Template.fromStack(stack);

  template.hasResourceProperties('AWS::SQS::Queue', {
    VisibilityTimeout: 300
  });
});

//test2
test("synthesizes the way we expect", () => {
  const app = new cdk.App();

  // Create the Sprint3Stack.
  const stack = new Sprint3.Sprint3Stack(app, 'MyTestStack');

  const template = Template.fromStack(stack);
  // Assert it creates the function with the correct properties...
template.hasResourceProperties("AWS::Lambda::Function", {
    Handler: "wh_lambda.handler",
    Runtime: "nodejs14.x",
  });

});

//test3
test("counting lambda functions ", () => {
  const app = new cdk.App();  const stack = new Sprint3.Sprint3Stack(app, 'MyTestStack');

  const template = Template.fromStack(stack);
  template.resourceCountIs("AWS::Lambda::Function", 2);
});

//test4
test("sns notification test", () => {
const app = new cdk.App();
const topicsStack = new cdk.Stack(app, "MyTopicsStack");

// Create the topic the stack we're testing will reference.
const topics = [new sns.Topic(topicsStack, "Topic1", {})];
// Create the Sprint3Stack.
const stack = new Sprint3.Sprint3Stack(app, 'MyTestStack');

const template = Template.fromStack(stack);
// Creates the subscription...
template.resourceCountIs("AWS::SNS::Subscription", 10);
});

