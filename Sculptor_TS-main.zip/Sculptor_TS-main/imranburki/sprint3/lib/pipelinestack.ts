import { Stack, StackProps,SecretValue } from 'aws-cdk-lib';
import { Construct } from 'constructs';
// import * as sqs from 'aws-cdk-lib/aws-sqs';
import * as pipelines from 'aws-cdk-lib/pipelines';
import * as actions_ from 'aws-cdk-lib/aws-codepipeline-actions';
//import { Secret } from 'aws-cdk-lib/aws-secretsmanager';

import {ImranStage as Stage}  from './stage';


export class MyPipelineStack extends Stack {
  constructor(scope: Construct, id: string, props?: StackProps) {
    super(scope, id, props);

    // The code that defines your stack goes here
  
    //defining my source 
    let source=pipelines.CodePipelineSource.gitHub('imranburki2022skipq/Sculptor_TS', 'main',{
      authentication: SecretValue.secretsManager('imran-token'),
      trigger:actions_.GitHubTrigger.POLL
    }
    );
    //Build Step
    // build my code with shellstep
    let mysynth= new pipelines.ShellStep('ImranBurkSynth', {
      // Use a connection created using the AWS console to authenticate to GitHub
      // Other sources are available.
      input:source ,
      commands: [
        'cd imranburki/sprint3',
        'npm ci',
        'npm run build',
        'npm install -g aws-cdk',
        'npx cdk synth'
      ],
      primaryOutputDirectory:'imranburki/sprint3/cdk.out'
    });
  
    // creating my pipeling
  //  https://docs.aws.amazon.com/cdk/api/v2/docs/aws-cdk-lib.pipelines-readme.html
    const mypipeline = new pipelines.CodePipeline(this, 'ImranBurkiPipeline', {
      synth:mysynth,
      })  
  /* Uncomment the next line if you know exactly what Account and Region you
   * want to deploy the stack to. */
  // env: { account: '123456789012', region: 'us-east-1' },
  //let Stage=new ImranStage.stage;


  //unit testing 
  const  unit_testing=new pipelines.ShellStep('unitTesting',{
    commands:
    [
    'cd imranburki/sprint3',
    'npm ci',
    'npm run test'
  ]
} );


//staging step
  let env={account: process.env.CDK_DEFAULT_ACCOUNT, region: process.env.CDK_DEFAULT_REGION };
  let betaStage=new Stage(this, 'ImranbetaStage');
  let gammaStage= new Stage(this,'ImrangammaStage')
  let productionStage= new Stage(this,'ImranProductionStage')

  //adding stage
  mypipeline.addStage(betaStage,{pre: [unit_testing]});
  mypipeline.addStage(gammaStage)
  mypipeline.addStage(productionStage,
    {
      post:
      [
        new pipelines.ManualApprovalStep('ImranApproval'),
        new pipelines.ManualApprovalStep('BurkiApproval')
     ]
    }
)  
  }
}
