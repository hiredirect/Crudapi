import { Stack, StackProps,SecretValue,Stage } from 'aws-cdk-lib';
import { Construct } from 'constructs';
import {Sprint3Stack} from  './sprint3-stack'

export class ImranStage extends Stage {
    stage:any
  constructor(scope: Construct, id: string, props?: StackProps) {
    super(scope, id, props);
    //instantiate application
    this.stage=new Sprint3Stack(this,'ImranApplication');
  };

}