# AWS CI/CD with GitHub [CodePipeline, CodeBuild, CodeDeploy]

This is an example of a CodePipeline cross-account CI/CD pipeline. The pipeline leverages CodeCommit as a Git repository, CodeBuild to package the source code for a sample Lambda and to build a CloudFormation template for our application. Moreover, the pipeline uses CodeDeploy to deploy the sample application. 

![image](https://drive.google.com/uc?export=view&id=1pB5VCC4MJ74ShAaLOxRESG-SZYOJ75SY)
## Useful commands
* `npm run build`   compile typescript to js
* `npm run watch`   watch for changes and compile
* `npm run test`    perform the jest unit tests
* `cdk deploy`      deploy this stack to your default AWS account/region
* `cdk diff`        compare deployed stack with current state
* `cdk synth`       emits the synthesized CloudFormation template
 ## The CDK consists of following stacks
 * DevApplicationStack: the sample application to be deployed by the pipeline on the dev environment
 * ProdApplicationStack: the sample application to be deployed by the pipeline on the prod environment
 * PipelineStack: the pipeline itself, along with other resources like CodeBuild, S3, KMS, etc.
 * RepositoryStack: a CodeCommit Git repository
