# Deploying WebHealth Lambda Funcion

This is a project creating WebHealth Lambda Funcion with TypeScript.

## Useful commands

* `npm run build`   compile typescript to js
* `npm run watch`   watch for changes and compile
* `npm run test`    perform the jest unit tests
* `cdk deploy`      deploy this stack to your default AWS account/region
* `cdk diff`        compare deployed stack with current state
* `cdk synth`       emits the synthesized CloudFormation template
# Steps
* Create Lambda funcion for Latency and Availability Metrices of one or multiple websites
* Publish these metrices on AWS CloudWatch 
  * Define IAM Role
* Generate Alarms on each metric
* Use SNS Notification services to send notification to sns topic
* Store alarms in dynamoDB 
