const AWS = require('aws-sdk');
AWS.config.update({ region: 'us-east-1' });
export class DynamoDBManipulateData {

    addData(tableName: any, msgId: any,message:any,subject:any) {
        // Create the DynamoDB service object
        const dynamodb = new AWS.DynamoDB();

        const params = {
            Item: {
                "id": {
                    S: msgId
                },
                "message":{
                    S:message
                },
                "Subject":{
                    S:subject
                }

            },
            ReturnConsumedCapacity: "TOTAL",
            TableName: tableName
        };
        dynamodb.putItem(params, function (err: any, data: any) {
            if (err) console.log(err, err.stack); // an error occurred
            else console.log(data);           // successful response

        });


    }
}