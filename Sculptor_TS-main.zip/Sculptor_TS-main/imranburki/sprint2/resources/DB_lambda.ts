import { ParameterGroup } from "aws-cdk-lib/aws-rds"
//import * as AWS from 'aws-cdk-lib'
var AWS = require('aws-sdk');
import { DynamoDBManipulateData } from "./DynamoDBMainpulateData";
import * as db from 'aws-cdk-lib/aws-dynamodb';
exports.handler=async function(event:any){
  //return console.log('inside dynmo lambda',events)
    /*
    Populates the Table created in the Stack
    Args:
        The notification can be extracted from the event Parameter
    */
      //steps
    //1. read the SNS notification in the json format from the event parameter
    //console.log(res)
    //2. parse the fields in the file
    //3. pick and choose the information that you want to place in your db table
    //4. write to the table


      //  const msgObj = JSON.parse(event.Records[0].Sns.Message);



        const tableName = process.env.table;
        const msgId = event.Records[0].Sns.MessageId;
        const message=event.Records[0].Sns.Message;
        // const eventSource = event.Records[0].EventSource;
        // const alarmNewState = msgObj.NewStateValue;
        // const alarmOldState = msgObj.OldStateValue;
        // const region = msgObj.Region;
        // const AlarmStateChangeTime = msgObj.StateChangeTime;
        // const metricName = msgObj.Trigger.MetricName;
        // const nameSpace = msgObj.Trigger.Namespace;
        // const threshold = msgObj.Trigger.Threshold;
        // const url = msgObj.Trigger.Dimensions[0].value
        // const type = event.Records[0].Sns.Type
        const subject = event.Records[0].Sns.Subject;
        // const timeStampt = event.Records[0].Sns.Timestamp;
        // const signature = event.Records[0].Sns.Signature;
        // const signatureVersion = event.Records[0].Sns.SignatureVersion;

        const dbTable = new DynamoDBManipulateData();
    if (event.Records) {
        const res = dbTable.addData(tableName, msgId,message,subject);
    }
}