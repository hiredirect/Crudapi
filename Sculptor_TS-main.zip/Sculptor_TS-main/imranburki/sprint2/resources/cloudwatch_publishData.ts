const AWS=require('aws-sdk');


export class CloudWatchPublishData{
 
    publish_data(namespace_:string, metric_name:string,dimensions:any, metric_value:any){
        var cloudwatch= new AWS.CloudWatch();
        var params = {
            MetricData: [ /* required */
              {
                'MetricName': metric_name, /* required */
                'Dimensions': dimensions,
                'Value': metric_value,
              },
            ],
            Namespace: namespace_ /* required */
          };

          cloudwatch.putMetricData(params, function(err:any, data:any) {
            if (err) console.log(err, err.stack); // an error occurred
            else     console.log(data);           // successful response
          });
          console.log('in publish_data file',metric_name)
        
    }
}