import * as cdk from 'aws-cdk-lib';
import { Template } from 'aws-cdk-lib/assertions';
import * as sns from "aws-cdk-lib/aws-sns";
import * as Sprint2 from '../lib/sprint2-stack';

// example test. To run these tests, uncomment this file along with the
// example resource in lib/sprint2-stack.ts
// test('SQS Queue Created', () => {
//   const app = new cdk.App();
//     // WHEN
//   const stack = new Sprint2.Sprint2Stack(app, 'MyTestStack');
//     // THEN
//   const template = Template.fromStack(stack);

//   template.hasResourceProperties('AWS::SQS::Queue', {
//     VisibilityTimeout: 300
//   });
// });

//test1
test("synthesizes the way we expect", () => {
      const app = new cdk.App();
      // Since the ProcessorStack consumes resources from a separate stack
      // (cross-stack references), we create a stack for our SNS topics to live
      // in here. These topics can then be passed to the ProcessorStack later,
      // creating a cross-stack reference.
    //  const topicsStack = new cdk.Stack(app, "MyTopicsStack");
      // Create the topic the stack we're testing will reference.
  //    const topics = [new sns.Topic(topicsStack, "Topic1", {})];
      // Create the ProcessorStack.
      const stack = new Sprint2.Sprint2Stack(app, 'MyTestStack');
    
      const template = Template.fromStack(stack);

      // Assert it creates the function with the correct properties...
    template.hasResourceProperties("AWS::Lambda::Function", {
        Handler: "wh_lambda.handler",
        Runtime: "nodejs14.x",
      });
  
      // Creates the subscription...
   //   template.resourceCountIs("AWS::Lambda::Function", 2);
    });

//test2
test("counting lambda functions ", () => {
      const app = new cdk.App();
      // Since the ProcessorStack consumes resources from a separate stack
      // (cross-stack references), we create a stack for our SNS topics to live
      // in here. These topics can then be passed to the ProcessorStack later,
      // creating a cross-stack reference.
    //  const topicsStack = new cdk.Stack(app, "MyTopicsStack");
      // Create the topic the stack we're testing will reference.
  //    const topics = [new sns.Topic(topicsStack, "Topic1", {})];
      // Create the ProcessorStack.
      const stack = new Sprint2.Sprint2Stack(app, 'MyTestStack');
    
      const template = Template.fromStack(stack);

      // Assert it creates the function with the correct properties...
    // template.hasResourceProperties("AWS::Lambda::Function", {
    //     Handler: "wh_lambda.handler",
    //     Runtime: "nodejs14.x",
    //   });
  
      // Creates the subscription...
      template.resourceCountIs("AWS::Lambda::Function", 2);
    });

//test3
test("sns notification test", () => {
    const app = new cdk.App();
    const topicsStack = new cdk.Stack(app, "MyTopicsStack");
    
    // Create the topic the stack we're testing will reference.
    const topics = [new sns.Topic(topicsStack, "Topic1", {})];
    // Create the ProcessorStack.
    const stack = new Sprint2.Sprint2Stack(app, 'MyTestStack');

    const template = Template.fromStack(stack);
    // Assert it creates the function with the correct properties...

    // Creates the subscription...
    template.resourceCountIs("AWS::SNS::Subscription", 8);
  });
