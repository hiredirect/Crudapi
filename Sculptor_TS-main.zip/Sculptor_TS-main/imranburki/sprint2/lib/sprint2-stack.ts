import { Stack, StackProps,RemovalPolicy,Duration} from 'aws-cdk-lib';

import { Construct } from 'constructs';
import * as sqs from 'aws-cdk-lib/aws-sqs';
import * as lambda from 'aws-cdk-lib/aws-lambda';
import { Rule, Schedule } from 'aws-cdk-lib/aws-events';
import *  as targets from 'aws-cdk-lib/aws-events-targets';
import * as constants from '../resources/constants';
import * as cloudwatch from 'aws-cdk-lib/aws-cloudwatch';
import * as iam from 'aws-cdk-lib/aws-iam'; //iam role
import * as cw_actions from 'aws-cdk-lib/aws-cloudwatch-actions'
import * as sns from 'aws-cdk-lib/aws-sns';
import * as subscriptions from 'aws-cdk-lib/aws-sns-subscriptions';
import * as db from 'aws-cdk-lib/aws-dynamodb';
//import * as AWS from 'aws-sdk';

export class Sprint2Stack extends Stack {
  constructor(scope: Construct, id: string, props?: StackProps) {
    super(scope, id, props);

    // The code that defines your stack goes here
    // example resource
    const queue = new sqs.Queue(this, 'Sprint2Queue', {
      visibilityTimeout: Duration.seconds(300)
    });

    

   const layer= new lambda.LayerVersion(this, 'MyLayer_imranBurki', {
      removalPolicy: RemovalPolicy.RETAIN,
      code: lambda.Code.fromAsset('layer')
    });

    const role=this.create_lambda_Role(constants.CLOUDWATCH_POLICY);
    const webHealthLambda=this.createLambda('imranburkiWBHLambdaEventBridge','./resources','wh_lambda.handler',layer,role);
    
    //calling create_role_for_DynamoDB

    // Lambda function that writes to DynamoDB table
    //const role=this.create_lambda_Role(constants.CLOUDWATCH_POLICY);
    const DBLambda=this.createLambda('imranburkiDBLambda','./resources','DB_lambda.handler',layer,role);

    //creating a DynamoDB table
    // https://docs.aws.amazon.com/cdk/api/v2/docs/aws-cdk-lib.aws_dynamodb-readme.html

    // const table = new db.Table(this, 'newimranTable', {
    //   partitionKey: { name: 'msgId', type: db.AttributeType.HASH },

    // });
    const table=this.createNewTable();
    table.grantFullAccess(DBLambda);
    let tableName_=table.tableName;

    DBLambda.addEnvironment("table",tableName_);
   // process.env.tableName
    // console.log('table name is ',process.env.table)


    for(let i=0;i<constants.URL_TO_MONITOR.length;i++){
      // accessing metrics created in lambda using the identifiers: metric_name and dimensions
    let LatencyMetric=this.create_latencyMetric(constants.METRIC_NAME_LATENCY,constants.URL_TO_MONITOR[i]);
    let AvailibilityMetric=this.create_AvailibilityMetric(constants.METRIC_NAME_AVAILIBALITY,constants.URL_TO_MONITOR[i])
    
    // defining alarm id based on metric id and url
    let latency_alarm_id= constants.METRIC_NAME_LATENCY+'-'+ constants.URL_TO_MONITOR[i];
    let availibility_alam_id=constants.METRIC_NAME_AVAILIBALITY+'-'+constants.URL_TO_MONITOR[i];
    
    //latency Metric Alarm
    let Latency_alarm=this.create_LatencyAlarm(latency_alarm_id,cloudwatch.ComparisonOperator.GREATER_THAN_THRESHOLD,
      constants.LATENCY_THRESHOLD,constants.EVALUATION_PERIOD,LatencyMetric);

    //Availibility Metric Alarm
    let Availibility_alarm=this.create_AvailibilityAlarm(availibility_alam_id,cloudwatch.ComparisonOperator.LESS_THAN_THRESHOLD,
      constants.AVAILIBILITY_THRESHOLD,constants.EVALUATION_PERIOD,AvailibilityMetric);

    //  console.log('in stack file ',AvailibilityMetric)
   
    //sns topic
    //https://docs.aws.amazon.com/cdk/api/v2/docs/aws-cdk-lib.aws_sns-readme.html
    let topicName='webHealthNotification_Topic_'+constants.URL_TO_MONITOR[i];
    const myTopic = new sns.Topic(this, topicName);
    myTopic.applyRemovalPolicy(RemovalPolicy.DESTROY);

    //https://docs.aws.amazon.com/cdk/api/v2/docs/aws-cdk-lib.aws_sns_subscriptions-readme.html
    myTopic.addSubscription(new subscriptions.EmailSubscription('imran.burki.sculptor@gmail.com'));
    myTopic.addSubscription(new subscriptions.LambdaSubscription(DBLambda));
  
  //Defining alarmAction
  //https://docs.aws.amazon.com/cdk/api/v2/docs/aws-cdk-lib.aws_cloudwatch_actions.SnsAction.html
    
    Latency_alarm.addAlarmAction(new cw_actions.SnsAction(myTopic));
    Availibility_alarm.addAlarmAction(new cw_actions.SnsAction(myTopic));
    
  
  }
    


    // event-Bridge

    
    //creating new Rule
    
    new Rule(this, 'ScheduleRule', {
      schedule: Schedule.rate(Duration.minutes(5)),
      targets: [new targets.LambdaFunction(webHealthLambda)],
     });
  }

  //create Lambda function
  createLambda(id:string, path:string, handler:string,layer:any,role:any){
    return new lambda.Function(this, id , {
      runtime: lambda.Runtime.NODEJS_14_X,
      handler: handler,
      code: lambda.Code.fromAsset(path),      
      layers: [layer],
      role:role
    });
  }

  // defin role
  // https://docs.aws.amazon.com/cdk/api/v2/docs/aws-cdk-lib.aws_iam.Role.html
  create_lambda_Role(policyName:string){
    let lambda_role = new iam.Role(this, 'Role', {
      assumedBy: new iam.ServicePrincipal('lambda.amazonaws.com'),
      description: 'Cloud watch Role',
    });
    // assigning managed policy
    lambda_role.addManagedPolicy(iam.ManagedPolicy.fromAwsManagedPolicyName(policyName))
    lambda_role.addManagedPolicy(iam.ManagedPolicy.fromAwsManagedPolicyName('AmazonDynamoDBFullAccess'))
    return lambda_role;
  }


  // create role for DynamoDB
  // create_lambda_Role_for_DynamoDB(policyName:string){
  //   let lambda_role = new iam.Role(this, 'Role', {
  //     assumedBy: new iam.ServicePrincipal('lambda.amazonaws.com'),
  //     description: 'Cloud watch Role',
  //   });
  //   // assigning managed policy
  //   lambda_role.addManagedPolicy(iam.ManagedPolicy.fromAwsManagedPolicyName(policyName))
  //   lambda_role.addManagedPolicy(iam.ManagedPolicy.fromAwsManagedPolicyName('AmazonDynamoDBFullAccess'))
  //   return lambda_role;
  // }
  
  //creating Latency Metric function
  create_latencyMetric(metricType:string,url:string){
    let metricName= metricType;
    let dimensions={"URL":url}
    return new cloudwatch.Metric({
      metricName: metricName,
      namespace: constants.NAMESPACE,
      period:Duration.minutes(5),
      dimensionsMap:dimensions,
      label:'Latency Metric'
    })
  }

  
  //creating Availability metric function
  create_AvailibilityMetric(metricType:string,url:string){
    let metricName= metricType;
    let dimensions={"URL":url}
    return new cloudwatch.Metric({
      metricName: metricName,
      namespace: constants.NAMESPACE,
      period:Duration.minutes(5),
      dimensionsMap:dimensions,
      label:'Availibility Metric'
    })
  }


  // create an alarm on the specific metric
    // create an alarm on Latency metric
  create_LatencyAlarm(id:string,comparsion_type:cloudwatch.ComparisonOperator,threshold:number,
    evaluationPeriod:number, metric:any){
      let newid='AlarmOnLatency'+'-'+id
      return  new cloudwatch.Alarm(this, newid, {
        comparisonOperator: cloudwatch.ComparisonOperator.GREATER_THAN_THRESHOLD,
        threshold: threshold,
        evaluationPeriods: evaluationPeriod,
        metric: metric,
        datapointsToAlarm:1,
        treatMissingData: cloudwatch.TreatMissingData.MISSING
      });
  }

  

  // create an alarm on Availibility metric
  create_AvailibilityAlarm(id:string,comparsion_type:cloudwatch.ComparisonOperator,threshold:number,
    evaluationPeriod:number, metric:any){
      let newid='AlarmOnAvailibility'+'-'+id
      return  new cloudwatch.Alarm(this, newid, {
        comparisonOperator: cloudwatch.ComparisonOperator.LESS_THAN_THRESHOLD,
        threshold: threshold,
        evaluationPeriods: evaluationPeriod,
        metric: metric,
        datapointsToAlarm:1,
        treatMissingData: cloudwatch.TreatMissingData.MISSING
      });
  }

  //creating new Table
  createNewTable(){
    // var db = new AWS.DynamoDB();
      const table = new db.Table(this, 'imranSNSANotifications_Table', {
        partitionKey: { name: 'id', type: db.AttributeType.STRING },
      });
     
       return table
    }
}
