import { Stack, StackProps, RemovalPolicy } from 'aws-cdk-lib';
import { Construct } from 'constructs';
// import * as sqs from 'aws-cdk-lib/aws-sqs';
import * as lambda from 'aws-cdk-lib/aws-lambda';

export class Sprint1Stack extends Stack {
  constructor(scope: Construct, id: string, props?: StackProps) {
    super(scope, id, props);

    const hwlambda=this.createLambda('imranburkiLambda','./resources','HWLambda.handler');
    hwlambda.applyRemovalPolicy(RemovalPolicy.DESTROY);

    // The code that defines your stack goes here

    // example resource
    // const queue = new sqs.Queue(this, 'Sprint1Queue', {
    //   visibilityTimeout: cdk.Duration.seconds(300)
    // });
  }
  createLambda(id:string, path:string, handler:string){
    return new lambda.Function(this, id , {
      runtime: lambda.Runtime.NODEJS_14_X,
      handler: handler,
      code: lambda.Code.fromAsset(path),      
    });
  }

}


