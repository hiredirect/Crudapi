# AWS Lambda Function

This is a project for writing AWS Lambda Function with TypeScript.

# What is AWS Lambda
Lambda is a compute service that lets you run code without provisioning or managing servers. Lambda runs your code on a high-availability compute infrastructure and performs all of the administration of the compute resources, including server and operating system maintenance, capacity provisioning and automatic scaling, code monitoring and logging. With Lambda, you can run code for virtually any type of application or backend service. 
# Prerequisites
* Vs Code or any other your favourite Editor
* AWS CLI2 [installation link](https://docs.aws.amazon.com/cli/latest/userguide/getting-started-install.html)
* NVM and NPM 
* AWS cdk 
* * npm install -g aws-cdk
* AWS Configure
## Useful commands

* `npm run watch`   watch for changes and compile
*  `cdk synth`       emits the synthesized CloudFormation template
* `cdk deploy`      deploy this stack to your default AWS account/region
* `cdk diff`        compare deployed stack with current state
# Steps for creating your first Hello World Lambda function
1. create a new directory
2. open it in vscode
3. run command ``` cdk init app --language typescript ``` in vscode terminal 
4. open a new terminal in vscode and type command ``` npm run watch ```
5. Go to lib folder in the left bar of your vscode
   - There will be a file with .ts extension
   - write your lambda function code here
     - you can also see the documentation [lambda function](https://docs.aws.amazon.com/cdk/api/v2/docs/aws-cdk-lib.aws_lambda.Function.html)
     - call this function in the constructor
6. For creating a handler 
   - create a new folder in your project with named resources
     - create a new file with .ts extension
       - Write your handler code in this file
 7. Save your changes in all files
 8. Run command ``` cdk synth && cdk deploy ```
 9. sign in to aws account and search lambda
 10. click on functions
 11. search for your name
 12. click on your name
 13. go to test tabe
 14. press test button at right left
 15. click on execution result and see the status
  * if it is successful then you are done!
