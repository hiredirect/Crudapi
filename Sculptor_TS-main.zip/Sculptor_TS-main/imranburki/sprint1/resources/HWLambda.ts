exports.handler=async function(event:any){
    return 'Hello World Testing Lambda Function by imranBurki';
}