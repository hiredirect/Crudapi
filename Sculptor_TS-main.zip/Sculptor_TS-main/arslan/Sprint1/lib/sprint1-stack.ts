import { Stack, StackProps, aws_lambda } from 'aws-cdk-lib';
import { Construct } from 'constructs';
// import * as sqs from 'aws-cdk-lib/aws-sqs';

export class Sprint1Stack extends Stack {
  constructor(scope: Construct, id: string, props?: StackProps) {
    super(scope, id, props);

    const HWLambda =  new aws_lambda.Function(this, "HWLambda", {
      runtime: aws_lambda.Runtime.NODEJS_12_X,
      handler: "HelloWorldLambda.mylambdafunction",
      code: aws_lambda.Code.fromAsset("./resources")
    });

  }
}
