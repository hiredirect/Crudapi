# SkipQ 2022 Sprint1 Repo

## About The Project

This project represent the code for our SkipQ Sprint 1.
It contains cloud infrastructure with a simple hello world lambda function written using TypeScript

### Built With

* TypeScript
* AWS CDK

## Getting Started

To get a local copy up and running follow these simple example steps.

### Prerequisites

`sudo apt update`

`sudo apt install python3 python3-pip`

Now check the python version

`python3 --version`

### update the AWS CLI

`curl "https://awscli.amazonaws.com/awscli-exe-linux-x86_64.zip" -o "awscliv2.zip"` , to download the files

`sudo apt install unzip`, install unzip to your machine

`unzip awscliv2.zip` , unzip downloaded files

`sudo ./aws/install` , install unzipped files

Now check aws version

`aws --version`

Now clone the forked Repository

`git clone `

Install the requirements 

`curl -o- https://raw.githubusercontent.com/nvm-sh/nvm/v0.38.0/install.sh | bash`
`vim ~/.bash_profile` , press insert key

`export NVM_DIR="$([ -z "${XDG_CONFIG_HOME-}" ] && printf %s "${HOME}/.nvm" || printf %s "${XDG_CONFIG_HOME}/nvm")" [ -s "$NVM_DIR/nvm.sh" ] && \. "$NVM_DIR/nvm.sh" # This loads nvm` , press esc

`:x` to write and quit the write mode

`source ~/.bash_profile`

`nvm ls-remote`

`nvm install v16.3.0 && nvm use v16.3.0 && nvm alias default v16.3.0`

`npm install -g aws-cdk`


### To run this code, start with language setup

`cdk init app --language typescript`
  

finally, synthesize and deploy the code

`cdk synth`
`cdk deploy'

The `cdk.json` file tells the CDK Toolkit how to execute your app.

## Useful commands

* `npm run build`   compile typescript to js
* `npm run watch`   watch for changes and compile
* `npm run test`    perform the jest unit tests
* `cdk deploy`      deploy this stack to your default AWS account/region
* `cdk diff`        compare deployed stack with current state
* `cdk synth`       emits the synthesized CloudFormation template
