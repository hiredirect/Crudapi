exports.mylambdafunction = async function(event:any) {
    console.log(`Hello ${event.name}`);

}