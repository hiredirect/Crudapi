import { Stack, StackProps, pipelines, SecretValue, aws_codepipeline_actions as actions } from 'aws-cdk-lib';
import { ManualApprovalStep } from 'aws-cdk-lib/pipelines';
import { Construct } from 'constructs';
import { pipelineStages } from './pipelineStages';
// import * as sqs from 'aws-cdk-lib/aws-sqs';

export class pipelineStack extends Stack {
    constructor(scope: Construct, id: string, props?: StackProps) {
        super(scope, id, props);



        //defining source 
        const source = pipelines.CodePipelineSource.gitHub('Anjlee2022skipq/Sculptor_TS', 'main', {
            authentication: SecretValue.secretsManager('Anjlee-token'),
            trigger: actions.GitHubTrigger.POLL

        })


        //build code with shellstep
        const synth = new pipelines.ShellStep("AnjleeSynth", {
            input: source,
            commands: ['cd AnjleeDuseja/Sprint3/', 'npm ci', 'npm run build', 'npx cdk synth'],
            primaryOutputDirectory: 'AnjleeDuseja/Sprint3/cdk.out',



        });


        //creating pipeline
        const myPipeline = new pipelines.CodePipeline(this, "AnjleePipeline", {
            synth: synth
        });


        //creating stages
        const betaStage = new pipelineStages(this, "AnjleeBeta");

        const gammaStage = new pipelineStages(this, "AnjleeGamma");

        const prodStage = new pipelineStages(this, "AnjleeProd");

        //unit test

        const unitTest = new pipelines.ShellStep("AnjleeUnitTest", {
            input: source,
            commands: ['cd AnjleeDuseja/Sprint3/', 'npm ci', 'npm run test']
        })

        //adding stages to pipeline
        myPipeline.addStage(betaStage, {
            pre: [unitTest],
            post: [new ManualApprovalStep('beta passed')]
        });

        myPipeline.addStage(gammaStage, {
            pre: [new ManualApprovalStep('gamma passed')]
        });

        myPipeline.addStage(prodStage);



    }
}
