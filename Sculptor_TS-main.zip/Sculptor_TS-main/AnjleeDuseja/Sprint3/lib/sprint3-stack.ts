import { Stack, StackProps, RemovalPolicy, aws_codedeploy } from 'aws-cdk-lib';
import { Construct } from 'constructs';
import * as lambda from 'aws-cdk-lib/aws-lambda'
import { Schedule, Rule } from 'aws-cdk-lib/aws-events'
import { Duration, aws_events_targets as targets, aws_dynamodb as dynamodb, aws_cloudwatch as cw, aws_sns as sns, aws_sns_subscriptions as subscriptions, aws_cloudwatch_actions as cwActions } from 'aws-cdk-lib';
import { ManagedPolicy, Role, ServicePrincipal } from 'aws-cdk-lib/aws-iam';
import * as constant from "../resources/constants"
import { Alias } from 'aws-cdk-lib/aws-lambda';
import { LambdaDeploymentConfig, LambdaDeploymentGroup } from 'aws-cdk-lib/aws-codedeploy';
import { Metric } from 'aws-cdk-lib/aws-cloudwatch';

export class Sprint3Stack extends Stack {
  constructor(scope: Construct, id: string, props?: StackProps) {
    super(scope, id, props);


    //creating layer for lambda function
    const layer = new lambda.LayerVersion(this, 'MyLayer', {
      removalPolicy: RemovalPolicy.RETAIN,
      code: lambda.Code.fromAsset("layer"),
    });

    // arguments to pass to the WebHealthlambda function
    const lambda_id = "AnjleeLambda";
    const lambda_path = "./resources";
    const lambda_handler = "WebHealthLambda.lambda_handler";
    const lambda_layer = layer;
    const lambda_role = this.createLambdaRole();
    lambda_role.applyRemovalPolicy(RemovalPolicy.DESTROY);

    // arguments to pass to the DynamoDBlambda function
    const Dlambda_id = "AnjleeDBLambda";
    const Dlambda_handler = "DynamoDBLambda.lambda_handler";

    // calling the WebHealthlambda function
    const WebHealthMonitor = this.createLambda(lambda_id, lambda_path, lambda_handler, lambda_layer, lambda_role)
    //removal policy destroy so when cdk destroy the resource also get destroyed
    WebHealthMonitor.applyRemovalPolicy(RemovalPolicy.DESTROY);

    // calling the DynamoDBlambda function
    const DynamoDBLambda = this.createLambda(Dlambda_id, lambda_path, Dlambda_handler, lambda_layer, lambda_role)
    DynamoDBLambda.applyRemovalPolicy(RemovalPolicy.DESTROY);


    //creating table and adding envoirment variable to dynamoDBLambda function
    const alarmTable = this.createTable();
    alarmTable.grantFullAccess(DynamoDBLambda);
    alarmTable.applyRemovalPolicy(RemovalPolicy.DESTROY);
    DynamoDBLambda.addEnvironment("table", alarmTable.tableName)


    //generating event
    const eventLambda = Schedule.rate(Duration.minutes(60));
    //genrating target
    const WHTargetLambda = new targets.LambdaFunction(WebHealthMonitor);
    //rule to connect event to target
    const ruleLambda = new Rule(this, 'LambdaInvocationRule', {
      description: "Invoke lambda after 60 min",
      schedule: eventLambda,
      targets: [WHTargetLambda],
    });

    //creating connection b/w notification and DynamoDBLambda function
    const topic = new sns.Topic(this, 'MyTopic');
    topic.applyRemovalPolicy(RemovalPolicy.DESTROY);
    topic.addSubscription(new subscriptions.LambdaSubscription(DynamoDBLambda));


    //creating cloudwatch metric
    constant.arrayOfUrls.map(obj => {

      //creating availblity metric
      const availablityMetric = new cw.Metric({
        metricName: constant.METRICNAME_AVAILABLITY,
        namespace: constant.METRIC_NAMESPACE,
        label: "Availablity Metric",
        period: Duration.minutes(60),
        dimensionsMap: { "url": obj.URL_TO_MONITOR }
      });

      //creating latency metric
      const latencyMetric = new cw.Metric({
        metricName: constant.METRICNAME_LATENCY,
        namespace: constant.METRIC_NAMESPACE,
        label: "Latency Metric",
        period: Duration.minutes(60),
        dimensionsMap: { "url": obj.URL_TO_MONITOR }
      });

      /** creating availblity and latency Alarms
     it runs the handler function whenever event is triggered
     Args:
     scope
     id: identifier string
     comparisonOperator: comparison operator to check if metric is breaching.
     threshold: number value against which the specified statistic is compared.
     evaluationPeriod: The number of periods over which data is compared to the specified threshold.

     */

      //availblity Alarm
      const availblityAlarm = new cw.Alarm(this, `AvailblityAlarm_${obj.URL_TO_MONITOR}`, {
        comparisonOperator: cw.ComparisonOperator.LESS_THAN_THRESHOLD,
        threshold: 1,
        evaluationPeriods: 10,
        metric: availablityMetric
      });

      //latency Alarm
      const latencyAlarm = new cw.Alarm(this, `LatencyAlarm_${obj.URL_TO_MONITOR}`, {
        comparisonOperator: cw.ComparisonOperator.GREATER_THAN_THRESHOLD,
        threshold: 400,
        evaluationPeriods: 10,
        metric: latencyMetric
      });

      //adding actions to alarm, send notification to lambda function when alarm is triggered

      availblityAlarm.addAlarmAction(new cwActions.SnsAction(topic));
      availblityAlarm.applyRemovalPolicy(RemovalPolicy.DESTROY);

      latencyAlarm.addAlarmAction(new cwActions.SnsAction(topic));
      latencyAlarm.applyRemovalPolicy(RemovalPolicy.DESTROY);

    });

    const WHDurationMetric = new cw.Metric({
      metricName: "durationMetric",
      namespace: 'AWS/Lambda',
      dimensionsMap: { "function_name": WebHealthMonitor.functionName }
    });

    const WHDurationrAlarm = new cw.Alarm(this, `DurationAlarm`, {
      comparisonOperator: cw.ComparisonOperator.GREATER_THAN_THRESHOLD,
      threshold: 2000,
      evaluationPeriods: 10,
      metric: WHDurationMetric
    });
    WHDurationrAlarm.applyRemovalPolicy(RemovalPolicy.DESTROY);

    const WHErrorMetric = new cw.Metric({
      metricName: "errorMetric",
      namespace: 'AWS/Lambda',
      dimensionsMap: { "function_name": WebHealthMonitor.functionName }
    });


    const WHErrorAlarm = new cw.Alarm(this, `ErrorAlarm`, {
      comparisonOperator: cw.ComparisonOperator.GREATER_THAN_OR_EQUAL_TO_THRESHOLD,
      threshold: 1,
      evaluationPeriods: 10,
      metric: WHErrorMetric
    });
    WHErrorAlarm.applyRemovalPolicy(RemovalPolicy.DESTROY)



    const WHMonitorLambdaAlias = this.createAlias("AnjleeWHLambdaAlias", WebHealthMonitor.currentVersion);

    WHMonitorLambdaAlias.applyRemovalPolicy(RemovalPolicy.DESTROY);
    const WHLambdaDeployGroup = this.createLambdaDeploymentGroup(WHMonitorLambdaAlias, [WHDurationrAlarm, WHErrorAlarm]);
    WHLambdaDeployGroup.applyRemovalPolicy(RemovalPolicy.DESTROY);
  }


  /** creating lambda function 
     it runs the handler function whenever event is triggered
     Args:
     id: identifier string
     path: address string where handler function reside
     handler: string contains the filename.handlerFunctionName.
     layer: list of layers to be added to its execuion enviorment
     */
  createLambda(id: string, path: string, handler: string, layer: any, role: any) {

    return new lambda.Function(this, id, {
      runtime: lambda.Runtime.NODEJS_12_X,
      handler: handler,
      code: lambda.Code.fromAsset(path),
      role: role,
      layers: [layer],


    });
  }

  /** creating dynamodb table
    Args:
    scope:
    id: identifier string
    partitionKey: object of key-value pair defined as primary key
    */
  createTable() {
    return new dynamodb.Table(this, 'AlarmTable', {
      partitionKey: { name: 'id', type: dynamodb.AttributeType.STRING },
    });
  }

  /** creating lambda role as some service require that
   Args:
   scope:
   id: identifier string
   assumedBy: object of servicePrincipal
   ManagePolicies array of ploicies
   */
  createLambdaRole() {
    return new Role(this, "lambdaRole", {
      assumedBy: new ServicePrincipal('lambda.amazonaws.com'),
      managedPolicies: [ManagedPolicy.fromAwsManagedPolicyName('service-role/AWSLambdaBasicExecutionRole'),
      ManagedPolicy.fromAwsManagedPolicyName('cloudWatchFullAccess'),
      ManagedPolicy.fromAwsManagedPolicyName('AmazonDynamoDBFullAccess')]


    })
  };

  /** creating alias for particular version of lambda 
   Args:
   scope:
   id: identifier string
   aliasName: name of alias
   version: function version to which alias refers
   */
  createAlias(aliasName: string, version: any) {
    return new Alias(this, "AnjleeAlias", {
      aliasName: aliasName,
      version: version
    })
  };

  /** creating rollback feature for lambda when alarm triggers
    Args:
    scope:
    id: identifier string
    alias: lambda alias to shift traffic
    alarms: alarms associated with this deployment group
    deploymentConfig: deployment configuration for this group
    */

  createLambdaDeploymentGroup(alias: any, alarms: any) {
    return new LambdaDeploymentGroup(this, "AnjleeLambdaDeploymentGroup", {
      alias: alias,
      alarms: alarms,
      deploymentConfig: LambdaDeploymentConfig.LINEAR_10PERCENT_EVERY_1MINUTE
    })
  };

}
