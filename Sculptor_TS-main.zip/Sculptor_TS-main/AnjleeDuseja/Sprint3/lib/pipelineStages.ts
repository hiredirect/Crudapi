import { Stage, StackProps } from 'aws-cdk-lib';
import { Construct } from 'constructs';
import { Sprint3Stack } from './sprint3-stack';
// import * as sqs from 'aws-cdk-lib/aws-sqs';

export class pipelineStages extends Stage {
    constructor(scope: Construct, id: string, props?: StackProps) {
        super(scope, id, props);

        const stage = new Sprint3Stack(this, "AnjleeApplication")

    }
}