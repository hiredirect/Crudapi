import * as cdk from 'aws-cdk-lib';
import { Template } from 'aws-cdk-lib/assertions';
import * as Sprint3 from '../lib/sprint3-stack';

// example test. To run these tests, uncomment this file along with the
// example resource in lib/sprint3-stack.ts
// test('SQS Queue Created', () => {
//     const app = new cdk.App();
//     // WHEN
//     const stack = new Sprint3.Sprint3Stack(app, 'MyTestStack');
//     // THEN
//     const template = Template.fromStack(stack);

//     template.hasResourceProperties('AWS::SQS::Queue', {
//         VisibilityTimeout: 300
//     });
// });

test("lambda resourceCount test", () => {
    const app = new cdk.App();
    const stack = new Sprint3.Sprint3Stack(app, 'sprint3TestStack');
    const template = Template.fromStack(stack);
    template.resourceCountIs("AWS::Lambda::Function", 2);

});


test("sns-subscription test", () => {
    const app = new cdk.App();
    const stack = new Sprint3.Sprint3Stack(app, 'sprint3TestStack');
    const template = Template.fromStack(stack);
    template.hasResource("AWS::SNS::Subscription", {});

});


test("alarm test", () => {
    const app = new cdk.App();
    const stack = new Sprint3.Sprint3Stack(app, 'sprint3TestStack');
    const template = Template.fromStack(stack);
    template.findParameters('AlarmTable68A95781')

});

test("layer test", () => {
    const app = new cdk.App();
    const stack = new Sprint3.Sprint3Stack(app, 'sprint3TestStack');
    const template = Template.fromStack(stack);
    template.hasResourceProperties("AWS::Lambda::LayerVersion", {})

});
test("dynamodbResources test", () => {
    const app = new cdk.App();
    const stack = new Sprint3.Sprint3Stack(app, 'sprint3TestStack');
    const template = Template.fromStack(stack);
    template.findResources("AWS::DynamoDB::Table")

});
