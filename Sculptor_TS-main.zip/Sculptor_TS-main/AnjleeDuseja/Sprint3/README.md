# Web Health Monitoring App

## Create pipeline to automate the process continous integration and delivering

### Description

This project extends the web health monitor application by automating the process continous integration and delivery. To acheive the purpose it deploy multi-stage pipeline to automate the releases of web health monitoe application and add rollback feature when alarm get triggers so that app has safe and secure releases


## steps to run lambda function build with cdk

- create a pipleine stack and redirect app to pipeline stack
- define a code source 
- build the code with shellstep
- create a pipeline
- define stages and add that to pipeline
- define unit tests
- configure deployement group

## Helpful Links

- [aws-lambda module](https://docs.aws.amazon.com/cdk/api/v1/docs/aws-lambda-readme.html)
- [aws-amazon docs](https://aws.amazon.com/getting-started/hands-on/run-serverless-code/)
- [aws-layerVersion](https://docs.aws.amazon.com/cdk/api/v1/docs/@aws-cdk_aws-lambda.LayerVersion.html)
- [aws-events](https://docs.aws.amazon.com/cdk/api/v1/docs/aws-events-readme.html)
- [aws-events-target](https://docs.aws.amazon.com/cdk/api/v1/docs/aws-events-targets-readme.html)
- [aws-cloudwatch-alarms](https://docs.aws.amazon.com/cdk/api/v1/docs/@aws-cdk_aws-cloudwatch.Alarm.html)
- [aws-cloudwatch-alarm-actions](https://docs.aws.amazon.com/cdk/api/v1/docs/aws-cloudwatch-actions-readme.html)
- [aws-sns](https://docs.aws.amazon.com/cdk/api/v1/docs/aws-sns-readme.html)
- [sns-subscription](https://docs.aws.amazon.com/cdk/api/v1/docs/aws-sns-subscriptions-readme.html)
- [aws-dynamodb-table](https://docs.aws.amazon.com/cdk/api/v1/docs/@aws-cdk_aws-dynamodb.Table.html)
- [dynaodb-crudOperations](https://docs.aws.amazon.com/AWSJavaScriptSDK/latest/AWS/DynamoDB/DocumentClient.html)
- [aws-policies](https://gist.github.com/gene1wood/55b358748be3c314f956)
- [aws-pipeline](https://docs.aws.amazon.com/cdk/api/v1/docs/pipelines-readme.html)
- [aws-assertions](https://docs.aws.amazon.com/cdk/api/v1/docs/assertions-readme.html)
- [aws-codedeploy](https://docs.aws.amazon.com/cdk/api/v1/docs/aws-codedeploy-readme.html)

## Useful commands

- `npm run build` compile typescript to js
- `npm run watch` watch for changes and compile
- `npm run test` perform the jest unit tests
- `cdk deploy` deploy this stack to your default AWS account/region
- `cdk diff` compare deployed stack with current state
- `cdk synth` emits the synthesized CloudFormation template
- `npm install axios` install the axios package
