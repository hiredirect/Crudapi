//importing packages and array of objects required by functions
const axios = require("axios");
import { arrayOfUrls, METRICNAME_AVAILABLITY, METRICNAME_LATENCY, METRIC_NAMESPACE } from "./constants"
import { CloudWatchPublishData } from "./CloudWatchPublishData"

// handler function to process events whenever function is invoked

exports.lambda_handler = async function (event: any) {


    const cw = new CloudWatchPublishData();


    // iterate throw each url (4) in array and gets their availblity and latency and returns the url, availblity and latency
    const promises = arrayOfUrls.map(async obj => {

        const dimensions = [{ 'Name': 'url', 'Value': obj.URL_TO_MONITOR }]

        const avail = await getAvailablity(obj.URL_TO_MONITOR);
        cw.publish_data(METRICNAME_AVAILABLITY, dimensions, avail, METRIC_NAMESPACE)

        const latency = await getLatency(obj.URL_TO_MONITOR);
        cw.publish_data(METRICNAME_LATENCY, dimensions, latency, METRIC_NAMESPACE)

        return {
            "url": obj.URL_TO_MONITOR,
            "availblity": avail,
            "latency": latency
        }
    })

    const result = await Promise.all(promises)
    return result;

};

/** function to get the latency of website
 Args
  url: string of web address
  return the delay time required by website
 **/
async function getLatency(url: string) {
    let startTime = new Date().getTime();
    let response = await axios.get(url);
    let endTime = new Date().getTime();
    let delta = endTime - startTime;
    return delta;

}
/** function to get the availablity of website
 Args
  url: string of web address
  return 1 if website is accessible otherwise 0
 **/
async function getAvailablity(url: string) {
    let res = await axios.get(url);
    if (res.status == 200)
        return 1.0;
    return 0.0;
}