const AWS = require('aws-sdk');
AWS.config.update({ region: 'us-east-1' });


export class DynamoDBManipulateData {
    /** function add data to dynamodb
        Args
        tableName: string of table name where data be insterted
        eventSource: string of source of event
        metricName: string of metric name
        nameSpace: string of namespace name
        url: string of web url
        type: string of event type
        timestampt: string of time 
        alarmOldState: enum string of alarm state {ALARM, OK, SuFFICANT DATA}
        alarmNewState: enum string of alarm state {ALARM, OK, SuFFICANT DATA}
        alarmStateChangeTime: string of time when alarm state changed
        region: string of region name

        return data inserted in table or throws error

        **/

    addData(tableName: any, msgId: any, eventSource: any, metricName: any, nameSpace: any, url: any, type: any, timeStampt: any, alarmNewState: any, alarmOldState: any, AlarmStateChangeTime: any, region: any) {

        // Create the DynamoDB service object
        const dynamodb = new AWS.DynamoDB();

        // data which need to be stored in dynamodb
        const params = {
            Item: {
                "id": {
                    S: msgId
                },
                "eventSource": {
                    S: eventSource
                },
                "metricName": {
                    S: metricName
                },
                "nameSpace": {
                    S: nameSpace
                },
                "url": {
                    S: url
                },
                "type": {
                    S: type
                },
                "timeStampt": {
                    S: timeStampt
                },
                "alarmNewState": {
                    S: alarmNewState
                },
                "alarmOldState": {
                    S: alarmOldState
                },
                "AlarmStateChangeTime": {
                    S: AlarmStateChangeTime
                },
                "region": {
                    S: region
                }
            },
            ReturnConsumedCapacity: "TOTAL",
            // name of the destination table
            TableName: tableName
        };

        //calling function to put data to table or throws error
        dynamodb.putItem(params, function (err: any, data: any) {
            if (err) console.log(err, err.stack); // an error occurred
            else console.log(data);           // successful response

        });


    }
}