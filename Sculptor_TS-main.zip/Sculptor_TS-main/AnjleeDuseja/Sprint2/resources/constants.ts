//array of urls for which we want to find availablity and latency
export const arrayOfUrls = [
    {
        "URL_TO_MONITOR": "https://developer.mozilla.org/en-US/docs/Web/JavaScript",
    },
    {
        "URL_TO_MONITOR": "https://www.iba.edu.pk/",
    },
    {
        "URL_TO_MONITOR": "https://www.skipQ.org",
    },
    {
        "URL_TO_MONITOR": "https://aws.amazon.com",
    }
]
export const METRIC_NAMESPACE = "AnjleeNameSpace";
export const METRICNAME_AVAILABLITY = "Url_Availablity"
export const METRICNAME_LATENCY = "Url_latency"