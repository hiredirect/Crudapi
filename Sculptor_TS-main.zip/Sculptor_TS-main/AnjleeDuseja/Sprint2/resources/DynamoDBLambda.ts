import { DynamoDBManipulateData } from "./DynamoDBManipulateData";

/** handler function to process events whenever function is invoked
 Args:
 event: json format document
Lambda runtime converts the event to an object and passes it to function code.
**/
exports.lambda_handler = async function (event: any) {



    //parsing string to object 
    const msgObj = JSON.parse(event.Records[0].Sns.Message);

    //accessing table using enviorment variable
    const tableName = process.env.table;

    //extracting data from event and msgObj object
    const msgId = event.Records[0].Sns.MessageId;
    const eventSource = event.Records[0].EventSource;
    const alarmNewState = msgObj.NewStateValue;
    const alarmOldState = msgObj.OldStateValue;
    const region = msgObj.Region;
    const AlarmStateChangeTime = msgObj.StateChangeTime;
    const metricName = msgObj.Trigger.MetricName;
    const nameSpace = msgObj.Trigger.Namespace;
    const threshold = msgObj.Trigger.Threshold;
    const url = msgObj.Trigger.Dimensions[0].value
    const type = event.Records[0].Sns.Type
    const subject = event.Records[0].Sns.Subject;
    const timeStampt = event.Records[0].Sns.Timestamp;
    const signature = event.Records[0].Sns.Signature;
    const signatureVersion = event.Records[0].Sns.SignatureVersion;

    //creating instance of DynamoDBManipulateData class
    const dbTable = new DynamoDBManipulateData();

    //if event object contains alarm metadata call the addData function of dbTable
    if (event.Records) {
        const res = dbTable.addData(tableName, msgId, eventSource, metricName, nameSpace, url, type, timeStampt, alarmNewState, alarmOldState, AlarmStateChangeTime, region);
    }

}