//importing aws-sdk required to create cloudwatch instance
const AWS = require('aws-sdk');

//publish data to cloudwatch using sdk
export class CloudWatchPublishData {

    /** function publish data to cloudwatch
     Args
     metricName: string of metric name
     dimensions: array of object conatining url and its name
     value: number as value of metric 
     namespace string of namespace name
     return publish data or give error
     **/
    publish_data(metricName: string, dimensions: any, value: number, namespace: string) {
        const cw = new AWS.CloudWatch();


        cw.putMetricData(
            {
                MetricData: [
                    {
                        MetricName: metricName,
                        Dimensions: dimensions,
                        Value: value,
                    }],
                Namespace: namespace
            },
            function (err: any, data: any) {
                if (err) console.log(err, err.stack); // an error occurred
                else console.log(data);           // successful response
            }
        )
    }

}