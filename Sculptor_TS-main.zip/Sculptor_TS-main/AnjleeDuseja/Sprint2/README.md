# Web Health Monitoring App

## Lambda function to get the availablity and latency of web resources

### Description

This project use the lambda service to get the availblity and latency of 4 web URLs.In order to automate the event-target rule is applied which runs the WHLambda after every 10 mins. Using Cloudwatch service the metrics get published.Further this project demonstrate the alarms which are triggered whenever metrics breach the defined threshold. Threshold for availablity is set to 1 and for latency it is 400 whenever these gets breached alarm triggers. Moreover simple notification service is used to send the notification to some target which is lambda function in this project. lambda function then gets the alarm metadata and write the information in DynamoDB table.


## steps to run lambda function build with cdk

- go to the stack file
- create a layer which will be passed to lambda function
- import lambda function from package @aws-cdk/aws-lambda
- write a lambda function
- create the method to get the availblity of url
- create the method to get the latency of url
- create a handler function and pass that to lambda function
- specify runtime enviorment within function
- call the function within constructor
- create event-target rule to automatically trigger lambda after certain rate
- create alarms 
- define sns topic and subscribe lambda 
- define actions aganst alarm
- send alarm metadata to lambda
- write function to add data to dynamo database table
- run npm run watch to compile the ts files to js
- run cdk synth to translate the defined resources to AWS CloudFormation template
- run cdk deploy to deploy the stack to your AWS Account

## Helpful Links

- [aws-lambda module](https://docs.aws.amazon.com/cdk/api/v1/docs/aws-lambda-readme.html)
- [aws-amazon docs](https://aws.amazon.com/getting-started/hands-on/run-serverless-code/)
- [aws-layerVersion](https://docs.aws.amazon.com/cdk/api/v1/docs/@aws-cdk_aws-lambda.LayerVersion.html)
- [aws-events](https://docs.aws.amazon.com/cdk/api/v1/docs/aws-events-readme.html)
- [aws-events-target](https://docs.aws.amazon.com/cdk/api/v1/docs/aws-events-targets-readme.html)
- [aws-cloudwatch-alarms](https://docs.aws.amazon.com/cdk/api/v1/docs/@aws-cdk_aws-cloudwatch.Alarm.html)
- [aws-cloudwatch-alarm-actions](https://docs.aws.amazon.com/cdk/api/v1/docs/aws-cloudwatch-actions-readme.html)
- [aws-sns](https://docs.aws.amazon.com/cdk/api/v1/docs/aws-sns-readme.html)
- [sns-subscription](https://docs.aws.amazon.com/cdk/api/v1/docs/aws-sns-subscriptions-readme.html)
- [aws-dynamodb-table](https://docs.aws.amazon.com/cdk/api/v1/docs/@aws-cdk_aws-dynamodb.Table.html)
- [dynaodb-crudOperations](https://docs.aws.amazon.com/AWSJavaScriptSDK/latest/AWS/DynamoDB/DocumentClient.html)
- [aws-policies](https://gist.github.com/gene1wood/55b358748be3c314f956)

## Useful commands

- `npm run build` compile typescript to js
- `npm run watch` watch for changes and compile
- `npm run test` perform the jest unit tests
- `cdk deploy` deploy this stack to your default AWS account/region
- `cdk diff` compare deployed stack with current state
- `cdk synth` emits the synthesized CloudFormation template
- `npm install axios` install the axios package
