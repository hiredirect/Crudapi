# First Function with AWS Lambda

### Description

This project helps to understand the basic AWS Lambda service which runs without provisioning or managing servers.The AWS Lambda function has been created within stack. This function basically takes three arguments **id**, **path** , and **handler** where Lambda function handler is the method in function code that processes events. When your function is invoked, Lambda runs the handler method. path is where that handler function exist. In this project handler resides in resource directory. which log some message for now.

## steps to run lambda function build with cdk

- go to the stack file
- import lambda function from package @aws-cdk/aws-lambda
- write a lambda function
- create a handler function and pass that to lambda function
- specify runtime enviorment within function
- call the function within constructor
- run npm run watch to compile the ts files to js
- run cdk synth to translate the defined resources to AWS CloudFormation template
- run cdk deploy to deploy the stack to your AWS Account

## Helpful Links

- [aws-lambda module](https://docs.aws.amazon.com/cdk/api/v1/docs/aws-lambda-readme.html)
- [aws-amazon docs](https://aws.amazon.com/getting-started/hands-on/run-serverless-code/)

## Useful commands

- `npm run build` compile typescript to js
- `npm run watch` watch for changes and compile
- `npm run test` perform the jest unit tests
- `cdk deploy` deploy this stack to your default AWS account/region
- `cdk diff` compare deployed stack with current state
- `cdk synth` emits the synthesized CloudFormation template
