import { Stack, StackProps } from 'aws-cdk-lib';
import { Construct } from 'constructs';
import * as lambda from 'aws-cdk-lib/aws-lambda'

export class Sprint1Stack extends Stack {
  constructor(scope: Construct, id: string, props?: StackProps) {
    super(scope, id, props);

    // arguments to pass to the lambda function
    const lambda_id = "AnjleeLambda";
    const lambda_path = "./resources";
    const lambda_handler = "HelloWorldLambda.lambda_handler";

    // calling the lamda function
    const HWLambda = this.createLambda(lambda_id, lambda_path, lambda_handler)

  }

  /** creating lambda function 
   it runs the handler function whenever event is triggered
   Args:
   id: identifier string
   path: address string where handler function reside
   handler: string contains the filename.handlerFunctionName.
   
   */
  createLambda(id: string, path: string, handler: string) {

    return new lambda.Function(this, id, {
      runtime: lambda.Runtime.NODEJS_12_X,
      handler: handler,
      code: lambda.Code.fromAsset(path),
    });
  }
}
