/** handler function to process events whenever function is invoked
 Args:
 event: json format document
Lambda runtime converts the event to an object and passes it to function code.
**/
exports.lambda_handler = async function (event: any) {
    console.log(`Hello ${event.firstName}! welcome to SkipQ Cohort ${event.cohort} this is your first lambda function`)
}