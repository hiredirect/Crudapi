# CI/CD Pipeline 

## What is the CI/CD pipeline?
The continuous integration/continuous delivery (CI/CD) pipeline is an agile DevOps workflow focused on a frequent and reliable software delivery process. The methodology is iterative, rather than linear, which allows DevOps teams to write code, integrate it, run tests, deliver releases and deploy changes to the software collaboratively and in real-time.

## Project Description
This aim of this project to create CI/CD Pipeline to automatically build, test and deploy the updates/changes in Web health application (done in sprint2). 


## Steps to Run this Project
* Clone with Repo using command `git clone https://github.com/muhammadskipq2021/Sculptor_TS.git`
* Open Terminal and run this command `npm run watch`  to watch for changes and compile
* Then run this command `cdk synth` to emits the synthesized CloudFormation template
* Last step is to deploy stack to your default AWS account/region using this command `cdk deploy mypipeline`
* once it doen, now when you chnage/update code then just push changing to guthub using these command
*  `git add .`
*   `git commit 'updated'`
*   `git push`
*   pipeline will automatically depoloy the chnage/updated to AWS.

## Check Results
* Log In into AWS Console and open Pipeline.
* search your pipeline and check results

### Author
Muhammad Irfan Hassan Trainee @skipQ  muhammad.irfan.hassan.s@skipq.org

Thanks! Enjoy:)
