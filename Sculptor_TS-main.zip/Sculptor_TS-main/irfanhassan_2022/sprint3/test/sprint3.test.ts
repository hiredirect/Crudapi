import * as cdk from 'aws-cdk-lib';
import { Template } from 'aws-cdk-lib/assertions';     //from cloudformation template
import * as Sprint3 from '../lib/sprint3-stack';

//TEST TO CHECK LAMBDA FUNCTION ARE 2 
test("lambda resourceCount test", () => {
    const app = new cdk.App();
    const stack = new Sprint3.Sprint3Stack(app, 'sprint3TestStack');
    const template = Template.fromStack(stack);
    template.resourceCountIs("AWS::Lambda::Function", 2);

});

//test to check  sns subscription
test("sns-subscription test", () => {
    const app = new cdk.App();
    const stack = new Sprint3.Sprint3Stack(app, 'sprint3TestStack');
    const template = Template.fromStack(stack);
    template.hasResource("AWS::SNS::Subscription", {});

});

//TEST TO CHECK THE DYNAMO DB table Is created 
test("dynamodbResources test", () => {
    const app = new cdk.App();
    const stack = new Sprint3.Sprint3Stack(app, 'sprint3TestStack');
    const template = Template.fromStack(stack);
    template.findResources("AWS::DynamoDB::Table")

});