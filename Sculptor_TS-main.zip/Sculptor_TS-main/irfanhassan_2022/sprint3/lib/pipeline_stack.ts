import { Stack, StackProps, pipelines, SecretValue, aws_codepipeline_actions as actions } from 'aws-cdk-lib';
import { ManualApprovalStep } from 'aws-cdk-lib/pipelines';
import { Construct } from 'constructs';
import { pipelineStages } from './pipelineStages';

export class pipelineStack extends Stack {
    constructor(scope: Construct, id: string, props?: StackProps) {
        super(scope, id, props);

        //--------------------defining source (my github repo)----------------------------------------
        const source = pipelines.CodePipelineSource.gitHub('muhammadskipq2021/Sculptor_TS', 'main', {
            //can create secret key using this command 
            // aws secretsmanager create-secret --name <name> --secret-string <access token here>
            authentication: SecretValue.secretsManager('irfan-token'),
            trigger: actions.GitHubTrigger.POLL
        })

        //--------------------build code using shellstep------------------------------------------------
        const synth = new pipelines.ShellStep("IrfanHassanSynth", {
            input: source,
            commands: ['cd irfanhassan_2022/sprint3/', 'npm ci', 'npx cdk synth'],
            primaryOutputDirectory: 'irfanhassan_2022/sprint3/cdk.out',
        });

        //--------------------creating pipeline----------------------------------------------------
        const myPipeline = new pipelines.CodePipeline(this, "IrfanHassanPipeline", {
            synth: synth
        });

        //-------------------------creating 3 stages for our pipeline--------------------------------
        const betaStage = new pipelineStages(this, "Beta");
        const gammaStage = new pipelineStages(this, "Gamma");
        const prodStage = new pipelineStages(this, "Prod");

        //-------------------------unit test-------------------------------------------------------
        const unitTest = new pipelines.ShellStep("UnitTest", {
            input: source,
            commands: ['cd irfanhassan_2022/sprint3/', 'npm ci', 'npm run test']
        })

        //---------------------adding stages to pipeline------------------------------------------
        myPipeline.addStage(betaStage, {
            pre: [unitTest]       //first run test then deploy beta stage
        });

        myPipeline.addStage(gammaStage, {
            pre: [new ManualApprovalStep('Beta Stage Passed')]
            //adding mannual approval after successfully deploemnt of beta stage
        });

        myPipeline.addStage(prodStage, {
            pre: [new ManualApprovalStep('Gamma Stage Passed')]
            //adding mannual approval after successfully deploemnt of gamma stage
        });
    }
}