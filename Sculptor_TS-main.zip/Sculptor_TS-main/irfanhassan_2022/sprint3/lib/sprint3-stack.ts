import { Stack, StackProps, RemovalPolicy, Duration } from 'aws-cdk-lib';
import { Construct } from 'constructs';
import * as lambda from 'aws-cdk-lib/aws-lambda';
import { Alias } from 'aws-cdk-lib/aws-lambda';
import { Rule, Schedule } from 'aws-cdk-lib/aws-events';
import * as target from 'aws-cdk-lib/aws-events-targets';
import * as iam from 'aws-cdk-lib/aws-iam';
import * as cw from 'aws-cdk-lib/aws-cloudwatch';
import * as const_ from '.././resources/constants';
import * as sns_ from 'aws-cdk-lib/aws-sns';
import * as sns_subscription from 'aws-cdk-lib/aws-sns-subscriptions';
import * as cw_action from 'aws-cdk-lib/aws-cloudwatch-actions';
import * as dynamodb from 'aws-cdk-lib/aws-dynamodb';
import { LambdaDeploymentConfig, LambdaDeploymentGroup } from 'aws-cdk-lib/aws-codedeploy';

export class Sprint3Stack extends Stack {
  constructor(scope: Construct, id: string, props?: StackProps) {
    super(scope, id, props);

    //-----------------stack code start here----------------------------------------- 
    //   adding lambda layer because we are using axios.
    const mylayer = new lambda.LayerVersion(this, 'MylambdaLayer', {
      removalPolicy: RemovalPolicy.RETAIN,
      code: lambda.Code.fromAsset("layer"),
    });

    //---------------web health lambda function ---------------------------------
    const role = this.create_lambda_role();   //creating role for lambda to give it full access of cloudwatch
    role.applyRemovalPolicy(RemovalPolicy.DESTROY);
    const Web_Health_lambda = this.creat_lambdafunction('Irfan_WebHealth_Lambda', './resources', 'WH_lambda.handler', mylayer, role);
    Web_Health_lambda.applyRemovalPolicy(RemovalPolicy.DESTROY);
    //------------------ sheducle event and add lambda as target-----------------
    const rule = new Rule(this, 'myrule', {
      schedule: Schedule.rate(Duration.minutes(60)),        //will occure each after 1 hour
      targets: [new target.LambdaFunction(Web_Health_lambda)],
    });


    //---------------creating dynamodb table and lambda function-------------------------------------------- 
    const notification_table = this.create_dynamodb('irfanhassantable', 'TimeStamp');
    notification_table.applyRemovalPolicy(RemovalPolicy.DESTROY);
    const table_lambda_Role = this.create_tablelambda_role();    //creaating role to give it access to dynamodb
    table_lambda_Role.applyRemovalPolicy(RemovalPolicy.DESTROY);
    const dynamodb_lambda = this.creat_lambdafunction('IrfanHasssan_Dynamodb_Lambda', './resources', 'table_lambda.handler', mylayer, table_lambda_Role);
    dynamodb_lambda.applyRemovalPolicy(RemovalPolicy.DESTROY);
    notification_table.grantReadWriteData(dynamodb_lambda);      //giving write to lambda to write and read from table
    dynamodb_lambda.addEnvironment('Table_name', notification_table.tableName);   //stroing table name in lambda envirement

    //------------------creating sns TOPIC for notiifcation and add subscriber to it-----------------------------------------
    const snstopic = new sns_.Topic(this, 'IrfanWebHealth');
    snstopic.addSubscription(new sns_subscription.EmailSubscription("muhammad.irfan.hassan.s@skipq.org"));
    snstopic.addSubscription(new sns_subscription.LambdaSubscription(dynamodb_lambda));
    snstopic.applyRemovalPolicy(RemovalPolicy.DESTROY);
    //------------------ creatingmetrics and addig alarm to metric for all webpages ----------------------------
    let url_arr = const_.url;
    for (let i = 0; i < 4; i++) {
      //creating cloud watch metrics  for availability
      let dimension = { "URL": url_arr[i] };
      var avail_metric = new cw.Metric({
        namespace: const_.name_spcae,
        metricName: const_.metric_name_avail + url_arr[i],
        period: Duration.minutes(60),
        label: const_.metric_name_avail + '  ' + url_arr[i],
        dimensionsMap: dimension
      });
      //creating cloud watch metrics  for latency
      var latency_metric = new cw.Metric({
        namespace: const_.name_spcae,
        metricName: const_.metric_name_latency + url_arr[i],
        period: Duration.minutes(60),
        label: const_.metric_name_latency + '  ' + url_arr[i],
        dimensionsMap: dimension
      });

      //alarm on availability metrics
      var avail_alarm = new cw.Alarm(this, 'AlarmOnAvailibility ' + url_arr[i], {
        comparisonOperator: cw.ComparisonOperator.LESS_THAN_THRESHOLD,
        threshold: 1,
        evaluationPeriods: 1,
        metric: avail_metric
      });
      //alarm on latency metrics
      var latency_alarm = new cw.Alarm(this, 'AlarmOnLatency ' + url_arr[i], {
        comparisonOperator: cw.ComparisonOperator.GREATER_THAN_THRESHOLD,
        threshold: const_.threshold_latency[i],
        evaluationPeriods: 1,
        metric: latency_metric
      });

      //-------------------adding action to alarm-------------------------------- 
      avail_alarm.addAlarmAction(new cw_action.SnsAction(snstopic));
      avail_alarm.applyRemovalPolicy(RemovalPolicy.DESTROY);
      latency_alarm.addAlarmAction(new cw_action.SnsAction(snstopic));
      latency_alarm.applyRemovalPolicy(RemovalPolicy.DESTROY);
    }

    //----------------creating the metric for duration time of web health lambda function---------------
    const DurationMetric = new cw.Metric({
      metricName: "irfanWebHealthDuration",
      namespace: 'AWS/Lambda',
      dimensionsMap: { "function_name": Web_Health_lambda.functionName }
    });
    //-------------adding alarm to duration metric of web health lambda--------------------
    const DurationrAlarm = new cw.Alarm(this, `irfanWebHealthDuration`, {
      comparisonOperator: cw.ComparisonOperator.GREATER_THAN_THRESHOLD,
      threshold: 2000,
      evaluationPeriods: 10,
      metric: DurationMetric
    });
    DurationrAlarm.applyRemovalPolicy(RemovalPolicy.DESTROY);
    //----------------creating metric for web health lambda function to see error-------------
    const WHErrorMetric = new cw.Metric({
      metricName: "errorMetric",
      namespace: 'AWS/Lambda',
      dimensionsMap: { "function_name": Web_Health_lambda.functionName }
    });
    //------------adding alarm to error metric of webhealth lambda -------------------------
    const WHErrorAlarm = new cw.Alarm(this, `irfanErrorAlarm`, {
      comparisonOperator: cw.ComparisonOperator.GREATER_THAN_OR_EQUAL_TO_THRESHOLD,
      threshold: 1,
      evaluationPeriods: 10,
      metric: WHErrorMetric
    });
    WHErrorAlarm.applyRemovalPolicy(RemovalPolicy.DESTROY)
    // ----- storing the current version of webhealth lambda ----------------------------
    const WHLambdaAlias = new Alias(this, "irfanhassan_alias", {
      aliasName: "irfanWebHealthLambdaAlias",
      version: Web_Health_lambda.currentVersion
    });
    WHLambdaAlias.applyRemovalPolicy(RemovalPolicy.DESTROY);
    //------------------- adding deployment group-------------------------------------
    const WHLambdaDeployGroup = new LambdaDeploymentGroup(this, "irfanLambdaDeploymentGroup", {
      alias: WHLambdaAlias,
      alarms: [DurationrAlarm, WHErrorAlarm],
      deploymentConfig: LambdaDeploymentConfig.LINEAR_10PERCENT_EVERY_1MINUTE   //10 percent when alarm generate
    });
    WHLambdaDeployGroup.applyRemovalPolicy(RemovalPolicy.DESTROY);
  }

  //-----------------function to create a lambda function ------------------------------------
  //input arguments are id, path fo handler file, hanlder name, layer and role for lambda function
  //return lambda function
  creat_lambdafunction(id: string, path: string, handler: string, layer: any, role: any) {
    return new lambda.Function(this, id,
      {
        runtime: lambda.Runtime.NODEJS_12_X,
        handler: handler,
        code: lambda.Code.fromAsset(path),
        layers: [layer],
        role: role
      });
  }
  //------------------ function to create role for webhealth lambda -------------------------
  //return role
  create_lambda_role() {
    const lambdaRole = new iam.Role(this, 'WHlambdaRole', {
      assumedBy: new iam.ServicePrincipal('lambda.amazonaws.com'),
      managedPolicies: [
        iam.ManagedPolicy.fromAwsManagedPolicyName('service-role/AWSlambdaBasicExecutionRole'),
        iam.ManagedPolicy.fromAwsManagedPolicyName('CloudWatchFullAccess')
      ],
    });
    return lambdaRole;
  }
  //---------------------- function to create dynamo DB table ----------------------------
  // input argument are id and partition key for table
  //return a dynamodb table
  create_dynamodb(id: string, key: string) {
    const table = new dynamodb.Table(this, id, {
      partitionKey: { name: key, type: dynamodb.AttributeType.STRING },
      billingMode: dynamodb.BillingMode.PAY_PER_REQUEST
    });
    return table;
  }
  //----------------------fucntion to create role for lambda for dynamodb table----------------
  //return lambda role
  create_tablelambda_role() {
    const lambdaRole = new iam.Role(this, 'DynamoDBRole', {
      assumedBy: new iam.ServicePrincipal('lambda.amazonaws.com'),
      managedPolicies: [
        iam.ManagedPolicy.fromAwsManagedPolicyName('service-role/AWSlambdaBasicExecutionRole'),
        iam.ManagedPolicy.fromAwsManagedPolicyName('AmazonDynamoDBFullAccess'),
        iam.ManagedPolicy.fromAwsManagedPolicyName('AmazonSNSFullAccess')
      ],
    });
    return lambdaRole;
  }
}