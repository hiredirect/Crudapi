//----------------lambda handler start here-----------------------
exports.handler = async function (event: any) {
    //creating instance of SDK as AWS 
    const AWS = require('aws-sdk');
    //extract the timestamp and url from alarm notification 
    const msgObj = JSON.parse(event.Records[0].Sns.Message);
    const timeStampt = event.Records[0].Sns.Timestamp;
    const url = msgObj.Trigger.Dimensions[0].value
    //get table name from envirement of lambda
    let table_name = process.env.Table_name;
    var dynamodb = new AWS.DynamoDB();
    //creating parameter which we want to put in table
    var params = {
        Item: {
            "timeStampt": {
                S: timeStampt
            },
            "url": {
                S: url
            }
        },
        ReturnConsumedCapacity: "TOTAL",
        // name of the destination table
        TableName: table_name
    };
    //putitem is used to put params to table
    dynamodb.putItem(params, function (err: any, data: any) {
        if (err) console.log(err, err.stack); // an error occurred
        else console.log(data);           // successful response
    });
}