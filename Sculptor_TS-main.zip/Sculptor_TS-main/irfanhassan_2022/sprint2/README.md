# WebHealth Monitor(Latency & Availability)

## Project Description
This aim of this project to to measure availability and latency of web pages. It will update latency and availability after each 1 minu and will write metrics for latency and availability on cloudwatch using cloudwatch's API. Also set alarm to notify the subscriber when threshold for latency and avaialabilty is preached. Push SNS notification to subscriber using email address and also triger lambda and store alarm data into dynamodb when alarm generated. 

## Technologies 
Project is created with 
* Lambda
* CloudWatch
* DynamoDB
* SNS

## Steps to Run this Project
* Clone with Repo using command `git clone https://github.com/muhammadskipq2021/Sculptor_TS.git`
* Open Terminal and run this command `npm run watch`  to watch for changes and compile
* Then run this command `cdk synth` to emits the synthesized CloudFormation template
* Last step is to deploy stack to your default AWS account/region using this command `cdk deploy`

## Check Results
* Log In into AWS Console and open Cloud watch. you can see Metrics and alarms you have created.
* You can see SNS notification in your email address (added as subsciber) when alarm geenrated. 
* You can see alarms notification in dynamo DB table as well. 

### Author
Muhammad Irfan Hassan Trainee @skipQ  muhammad.irfan.hassan.s@skipq.org

Thanks! Enjoy:)
