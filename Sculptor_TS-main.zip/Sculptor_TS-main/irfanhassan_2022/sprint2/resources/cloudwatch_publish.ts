const AWS = require('aws-sdk');
export class cloudwatch_publish {
    //-----------------function to put data to metric ------------------------------------
    //input arguments are url of webpage, metric name, value and namespcae
    //return nothing
    put_data(url: string, metric_name: string, metric_value: Number, name_space: string) {

        var cloudwatch = new AWS.CloudWatch();
        var params = {
            MetricData: [ /* required */
                {
                    MetricName: metric_name + url, /* required */
                    Dimensions: [{
                        Name: 'URL', /* required */
                        Value: url /* required */
                    }],
                    Value: metric_value
                }],
            Namespace: name_space /* required */
        };

        cloudwatch.putMetricData(params, function (err: any, data: any) {
            if (err) console.log(err, err.stack); // an error occurred
            else console.log(data);           // successful response
        });
    }
}