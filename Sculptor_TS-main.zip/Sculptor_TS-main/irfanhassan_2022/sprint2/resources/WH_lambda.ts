//Web Health lambda function 
import * as const_ from './constants';
import { cloudwatch_publish } from "./cloudwatch_publish";
const axios = require("axios");    //axios to make api request to web urls. 

//----------------------handler start here ----------------------------------------

exports.handler = async function (event: any) {
    let url_arr = const_.url;
    for (let i = 0; i < 4; i++) {
        let avail = await getavailbility(url_arr[i]);
        let latency = await getlatency(url_arr[i]);
        let cw_publsh = new cloudwatch_publish();
        cw_publsh.put_data(url_arr[i], const_.metric_name_latency, latency, const_.name_spcae);  //put latency data to metric
        cw_publsh.put_data(url_arr[i], const_.metric_name_avail, avail, const_.name_spcae);     //put availability data to metric
    }
}
//------------function to get latecy of webpage------------------------------
//input argument is url of webpage as string
//return latency as number
async function getlatency(url: string) {
    let start = new Date().getTime();
    let latency = await axios.get(url);
    let end = new Date().getTime();
    return end - start;
}
//----------------fuunction to get availabilyt of webpage -------------------
//input argument is url of webpage as string
//return 1 if available else return 0 
async function getavailbility(url: string) {
    let avail = await axios.get(url);
    if (avail.status == 200) {
        return 1.0;
    }
    else {
        return 0.0;
    }
}