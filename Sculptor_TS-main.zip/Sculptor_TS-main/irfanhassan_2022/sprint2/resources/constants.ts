export let url = ["https://www.amazon.com", "https://www.binance.com", "https://www.netflix.com", "https://www.skipq.org/"];
export let threshold_latency = [500, 350, 500, 450];
export let name_spcae = "IrfanHassan";
export let metric_name_latency = "latencymetric";
export let metric_name_avail = "availabilitymetric";

