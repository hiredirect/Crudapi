import { Stack, StackProps, RemovalPolicy, Duration } from 'aws-cdk-lib';
import { Construct } from 'constructs';
import * as lambda from 'aws-cdk-lib/aws-lambda';
import { Rule, Schedule } from 'aws-cdk-lib/aws-events';
import * as target from 'aws-cdk-lib/aws-events-targets';
import * as iam from 'aws-cdk-lib/aws-iam';
import * as cw from 'aws-cdk-lib/aws-cloudwatch';
import * as const_ from '.././resources/constants';
import * as sns_ from 'aws-cdk-lib/aws-sns';
import * as sns_subscription from 'aws-cdk-lib/aws-sns-subscriptions';
import * as cw_action from 'aws-cdk-lib/aws-cloudwatch-actions';
import * as dynamodb from 'aws-cdk-lib/aws-dynamodb';


export class Sprint2Stack extends Stack {
  constructor(scope: Construct, id: string, props?: StackProps) {
    super(scope, id, props);

    //-----------------stack code start here----------------------------------------- 
    //   adding lambda layer because we are using axios.
    const mylayer = new lambda.LayerVersion(this, 'MylambdaLayer', {
      removalPolicy: RemovalPolicy.DESTROY,
      code: lambda.Code.fromAsset("layer"),
    });

    //---------------web health lambda function ---------------------------------
    const role = this.create_lambda_role();   //creating role for lambda to give it full access of cloudwatch
    const Web_Health_lambda = this.creat_lambdafunction('Irfan_WebHealth_Lambda', './resources', 'WH_lambda.handler', mylayer, role);

    //------------------ sheducle event and add lambda as target-----------------
    const rule = new Rule(this, 'myrule', {
      schedule: Schedule.rate(Duration.minutes(1)),        //will occure each after 1 minute
      targets: [new target.LambdaFunction(Web_Health_lambda)],
    });

    //---------------creating dynamodb table and lambda function-------------------------------------------- 
    const notification_table = this.create_dynamodb('irfanhassantable', 'TimeStamp');
    const table_lambda_Role = this.create_tablelambda_role();    //creaating role to give it access to dynamodb
    const dynamodb_lambda = this.creat_lambdafunction('IrfanHasssan_Dynamodb_Lambda', './resources', 'table_lambda.handler', mylayer, table_lambda_Role);
    notification_table.grantReadWriteData(dynamodb_lambda);      //giving write to lambda to write and read from table
    dynamodb_lambda.addEnvironment('Table_name', notification_table.tableName);   //stroing table name in lambda envirement

    //------------------creating sns TOPIC for notiifcation and add subscriber to it-----------------------------------------
    const snstopic = new sns_.Topic(this, 'IrfanWebHealth');
    snstopic.addSubscription(new sns_subscription.EmailSubscription("muhammad.irfan.hassan.s@skipq.org"));
    snstopic.addSubscription(new sns_subscription.LambdaSubscription(dynamodb_lambda));

    //------------------ creatingmetrics and addig alarm to metric for all webpages ----------------------------
    let url_arr = const_.url;
    for (let i = 0; i < 4; i++) {
      //creating cloud watch metrics  for availability
      let dimension = { "URL": url_arr[i] };
      var avail_metric = new cw.Metric({
        namespace: const_.name_spcae,
        metricName: const_.metric_name_avail + url_arr[i],
        period: Duration.minutes(1),
        label: const_.metric_name_avail + '  ' + url_arr[i],
        dimensionsMap: dimension
      });
      //creating cloud watch metrics  for latency
      var latency_metric = new cw.Metric({
        namespace: const_.name_spcae,
        metricName: const_.metric_name_latency + url_arr[i],
        period: Duration.minutes(1),
        label: const_.metric_name_latency + '  ' + url_arr[i],
        dimensionsMap: dimension
      });

      //alarm on availability metrics
      var avail_alarm = new cw.Alarm(this, 'AlarmOnAvailibility ' + url_arr[i], {
        comparisonOperator: cw.ComparisonOperator.LESS_THAN_THRESHOLD,
        threshold: 1,
        evaluationPeriods: 1,
        metric: avail_metric
      });
      //alarm on latency metrics
      var latency_alarm = new cw.Alarm(this, 'AlarmOnLatency ' + url_arr[i], {
        comparisonOperator: cw.ComparisonOperator.GREATER_THAN_THRESHOLD,
        threshold: const_.threshold_latency[i],
        evaluationPeriods: 1,
        metric: latency_metric
      });

      //-------------------adding action to alarm-------------------------------- 
      avail_alarm.addAlarmAction(new cw_action.SnsAction(snstopic));
      latency_alarm.addAlarmAction(new cw_action.SnsAction(snstopic));
    }
  }

  //-----------------function to create a lambda function ------------------------------------
  //input arguments are id, path fo handler file, hanlder name, layer and role for lambda function
  //return lambda function
  creat_lambdafunction(id: string, path: string, handler: string, layer: any, role: any) {
    return new lambda.Function(this, id,
      {
        runtime: lambda.Runtime.NODEJS_12_X,
        handler: handler,
        code: lambda.Code.fromAsset(path),
        layers: [layer],
        role: role
      });
  }
  //------------------ function to create role for webhealth lambda -------------------------
  //return role
  create_lambda_role() {
    const lambdaRole = new iam.Role(this, 'WHlambdaRole', {
      assumedBy: new iam.ServicePrincipal('lambda.amazonaws.com'),
      managedPolicies: [
        iam.ManagedPolicy.fromAwsManagedPolicyName('service-role/AWSlambdaBasicExecutionRole'),
        iam.ManagedPolicy.fromAwsManagedPolicyName('CloudWatchFullAccess')
      ],
    });
    return lambdaRole;
  }
  //---------------------- function to create dynamo DB table ----------------------------
  // input argument are id and partition key for table
  //return a dynamodb table
  create_dynamodb(id: string, key: string) {
    const table = new dynamodb.Table(this, id, {
      partitionKey: { name: key, type: dynamodb.AttributeType.STRING }
    });
    return table;
  }
  //----------------------fucntion to create role for lambda for dynamodb table----------------
  //return lambda role
  create_tablelambda_role() {
    const lambdaRole = new iam.Role(this, 'DynamoDBRole', {
      assumedBy: new iam.ServicePrincipal('lambda.amazonaws.com'),
      managedPolicies: [
        iam.ManagedPolicy.fromAwsManagedPolicyName('service-role/AWSlambdaBasicExecutionRole'),
        iam.ManagedPolicy.fromAwsManagedPolicyName('AmazonDynamoDBFullAccess'),
        iam.ManagedPolicy.fromAwsManagedPolicyName('AmazonSNSFullAccess')
      ],
    });
    return lambdaRole;
  }
}

