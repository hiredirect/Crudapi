# First Hello World Lambda Function
### Description
In Sprint1 hello world Lambda function has been created which is then deployed to the AWS.
### Basic Steps to creat Lambda function in Typescript
* open the stack file
* import lamda function 
* create lambda function within stack file 
* create handler 
* run command "npm run watch" to update js file
* run cdk  synth and cdk deploy command 



## Useful commands

* `npm run build`   compile typescript to js
* `npm run watch`   watch for changes and compile
* `npm run test`    perform the jest unit tests
* `cdk deploy`      deploy this stack to your default AWS account/region
* `cdk diff`        compare deployed stack with current state
* `cdk synth`       emits the synthesized CloudFormation template