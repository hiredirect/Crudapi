
import { Stack, StackProps } from 'aws-cdk-lib';
import { Construct } from 'constructs';
import * as lambda from 'aws-cdk-lib/aws-lambda';

// import * as sqs from 'aws-cdk-lib/aws-sqs';

export class Sprint1Stack extends Stack {
  constructor(scope: Construct, id: string, props?: StackProps) {
    super(scope, id, props);
    // lamda id
    const id_lambda = 'FirstHWLambdaFunction';
    // path to lambda  handler
    const path = './resources';
    // name of lambda handler
    const hand = 'hw_lambda.handler';
    const hw = this.createLambda(id_lambda,path,hand);


  }
// defining the Lambda Function
  createLambda(id:string,path:string,handler:string){
    return new lambda.Function(this, id, {
      runtime: lambda.Runtime.NODEJS_12_X,
      handler: handler,
      code: lambda.Code.fromAsset(path),
    });
}
}