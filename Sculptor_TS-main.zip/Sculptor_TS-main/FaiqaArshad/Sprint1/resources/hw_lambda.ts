// lambda handler
exports.handler = async function(event:any) {
    console.log(`hello ${event.firstname}`)
}