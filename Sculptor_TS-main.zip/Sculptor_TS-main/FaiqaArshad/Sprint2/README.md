# Web Health Application
Web health application to monitor the health of 4 websites
## Description
Web health application which monitor the health of specified web resources using two metrics i-e Latency and Availability. Published these metrics to CloudWatch monitoring service then trigger an alarm by defining certain threshold and send notification using sns(Simple Notification Service) and finally stores Alarm’s information to DynamoDB.
## In order to monitor the health of applications two metrics is used listed as bellow: 

    1) latency 
    2) availibility


## Basic steps to create web health app
* Initialize the cdk app
* Write code to create lambda function
* Create handler function to resources
* Add tags to the sprint file
* Create an event periodically
* Use cloud watch service to monitor the health of application
* Create an alarm which trigger after certain threshold
* Recive the alarm notification
* save the alarm notificatio to DynamoDB
* finally synthesis and deploy 

## Basic commands

* `npm run build`   compile typescript to js
* `npm run watch`   watch for changes and compile
* `npm run test`    perform the jest unit tests
* `cdk deploy`      deploy this stack to your default AWS account/region
* `cdk diff`        compare deployed stack with current state
* `cdk synth`       emits the synthesized CloudFormation template
