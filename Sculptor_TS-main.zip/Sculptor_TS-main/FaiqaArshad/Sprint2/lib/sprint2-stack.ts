import { Stack, StackProps, RemovalPolicy, Duration } from 'aws-cdk-lib';
import { Construct } from 'constructs';
import * as lambda from 'aws-cdk-lib/aws-lambda';
import { Rule, Schedule } from 'aws-cdk-lib/aws-events';
import * as target from 'aws-cdk-lib/aws-events-targets';
import * as constants from '../resources/constant';
import * as cloudwatch from 'aws-cdk-lib/aws-cloudwatch';
import * as iam from 'aws-cdk-lib/aws-iam';
import { S3, Sns } from 'aws-cdk-lib/aws-ses-actions';
import * as s3 from 'aws-cdk-lib/aws-s3';
import * as sns from 'aws-cdk-lib/aws-sns';
import * as subscriptions from 'aws-cdk-lib/aws-sns-subscriptions';
import * as cw_actions from 'aws-cdk-lib/aws-cloudwatch-actions';
import * as s3deploy from 'aws-cdk-lib/aws-s3-deployment';
import { Subscription } from 'aws-cdk-lib/aws-sns';
import { getMaxListeners } from 'process';
import * as db from 'aws-cdk-lib/aws-dynamodb'

export class Sprint2Stack extends Stack {
  constructor(scope: Construct, id: string, props?: StackProps) {
    super(scope, id, props);

    // defining parameter to be be passed to lambda function
    const id_lambda = 'WHLambda';
    const path = './resources';
    const hand = 'wh_handler.handler';

    // creating layer
    const layer = new lambda.LayerVersion(this, 'MyLayer', {
      removalPolicy: RemovalPolicy.DESTROY,
      code: lambda.Code.fromAsset("layer")
    });



    // creating db table to write into database
    let table = new db.Table(this, 'FaiqaTable', {
      partitionKey: { name: 'id', type: db.AttributeType.STRING },
      removalPolicy: RemovalPolicy.DESTROY,
    });
    const role = this.create_lambda_role('CloudWatchFullAccess');
    //const role2 = this.create_DBlambda_role('AmazonDynamoDBFullAccess')
    const dbLambda = this.createDBLambda("DynamoDB_Lambda", './resources', 'DynamoDBLambda.handler', role);
    dbLambda.applyRemovalPolicy(RemovalPolicy.DESTROY);
    table.grantFullAccess(dbLambda);
    const tableNmae1 = table.tableName;
    dbLambda.addEnvironment('tableName',tableNmae1);
    // defining policy to give permission to publish metric to cloudWatch
   

    // defining the lambda function
    const hw = this.createLambda(id_lambda, path, hand, layer, role);
    hw.applyRemovalPolicy(RemovalPolicy.DESTROY);
    this.create_cron_job("WHMonitor", hw);



    
    //creating table
    let metricLatecny = this.create_Metric(constants.METRIC_NAME_LATENCY, constants.URL_TO_MONITOR);
    let metricaval = this.create_Metric(constants.METRIC_NAME_AVAILIBALITY, constants.URL_TO_MONITOR);

    //defining alaram id
    let lat_alarm_id = constants.METRIC_NAME_LATENCY + ' :' + constants.URL_TO_MONITOR;
    let aval_alarm_id = constants.METRIC_NAME_AVAILIBALITY + ' :' + constants.URL_TO_MONITOR;

    // calling the alarm function and passing the threshold and web resources to trigger an alarm
    let lat_alarm = this.create_alarm(lat_alarm_id, cloudwatch.ComparisonOperator.GREATER_THAN_THRESHOLD, constants.LATENCY_THRESHOLD, constants.EVALUATION_PERIOD, metricLatecny)
    let aval_alarm = this.create_alarm(aval_alarm_id, cloudwatch.ComparisonOperator.LESS_THAN_THRESHOLD, constants.AVAILIBILITY_THRESHOLD, constants.EVALUATION_PERIOD, metricaval)

    //adding sns service to recieve   email notification when alarm trigger
    const topic = new sns.Topic(this, 'Topic');
    // subscribe to the email to recieve email
    topic.addSubscription(new subscriptions.EmailSubscription('faiqa.arshad.skipq@gmail.com'))
    topic.addSubscription(new subscriptions.LambdaSubscription(dbLambda));
    // adding actions to alarm
    lat_alarm.addAlarmAction(new cw_actions.SnsAction(topic));
    aval_alarm.addAlarmAction(new cw_actions.SnsAction(topic));
  }

  // creation of lambda function and passing the handler 
  createLambda(id: string, path: string, handler: string, layer: any, role: any) {
    return new lambda.Function(this, id, {
      runtime: lambda.Runtime.NODEJS_12_X,
      timeout: Duration.minutes(5),
      handler: handler,
      layers: [layer],
      role: role,
      code: lambda.Code.fromAsset(path),
    });
  }

  // dynamodb database 
  createDBLambda(id: string, path: any, handler: any, role1:any) {
    return new lambda.Function(this, id, {
      runtime: lambda.Runtime.NODEJS_12_X,
      timeout: Duration.minutes(5),
      handler: handler,
      role: role1,
      code: lambda.Code.fromAsset(path),

    });}

  // creating a cron job function to schedule the invocation periodically
  create_cron_job(id: string, handler: any) {
    new Rule(this, 'ScheduleRule', {
      schedule: Schedule.rate(Duration.minutes(1)),
      targets: [new target.LambdaFunction(handler)],
    });
  }


  // creating a lambda role to define the policy of lamvda and dynamoblambda
  create_lambda_role(policyName: string) {
    const role1 = new iam.Role(this, 'Role', {
      assumedBy: new iam.ServicePrincipal('lambda.amazonaws.com'),
      description: 'cloudwatch role...',
    }); 
    role1.addManagedPolicy(iam.ManagedPolicy.fromAwsManagedPolicyName(policyName));
    role1.addManagedPolicy(iam.ManagedPolicy.fromAwsManagedPolicyName('AmazonDynamoDBFullAccess'));
    return role1;
  }

  // creating a role for dynamodbDatabse
  create_DBlambda_role(policyName: string) {
    const roledb = new iam.Role(this, 'Role', {
      assumedBy: new iam.ServicePrincipal('lambda.amazonaws.com'),
      description: 'cloudwatch role...',
    });
    roledb.addManagedPolicy(iam.ManagedPolicy.fromAwsManagedPolicyName(policyName));
    return roledb;
  }

  // creating an alarm fynction to trigger 
  create_alarm(id: string, comparison_type: cloudwatch.ComparisonOperator, threshold: number, evaluation_period: number,
    metric: any) {
    return new cloudwatch.Alarm(this, id, {
      comparisonOperator: comparison_type,
      threshold: threshold,
      evaluationPeriods: evaluation_period,
      metric: metric
    });  }


  // creating return metric
  create_Metric(metric_type: any, url: string[]) {
    let metricname = metric_type;
    let dimension;
    for (let i = 0; i < url.length; i++) {
      dimension = { "URL": url[i] }
    }
    return new cloudwatch.Metric({
      metricName: metricname,
      namespace: constants.NAMESPACE,
      // period: Duration.minutes(1),
      dimensionsMap: dimension
    });  }}