const AWS = require('aws-sdk');
AWS.config.update({ region: 'us-east-1' });


export class DynamoDBManipulateData {
    

    addData(tableName: any, msgId: any,  metric: any, nameSpace: any, url: any){
     
        const dynamodb = new AWS.DynamoDB();

      
        const params = {
            Item: {
                "id": {
                    S: msgId
                },
               
                "metricName": {
                    S: metric
                },
                "nameSpace": {
                    S: nameSpace
                },
                "url": {
                    S: url
                },
               
            },
            ReturnConsumedCapacity: "TOTAL",
          
            TableName: tableName
        };

        
        dynamodb.putItem(params, function (err: any, data: any) {
            if (err) console.log(err, err.stack); // an error occurred
            else console.log(data);           // successful response

        });


    }
}