export let NAMESPACE='WHNamespace';
// metrcic name for latency
export let METRIC_NAME_LATENCY="latency";
// metrcic name for availability
export let METRIC_NAME_AVAILIBALITY="availibility";
// URL to monitore or web resources names
export let URL_TO_MONITOR=["https://www.youtube.com","https://www.github.com/","https://nust.edu.pk/","https://www.google.com/"];
export let CLOUDWATCH_POLICY='CloudWatchFullAccess';
export let EVALUATION_PERIOD=1;
// threshold for latecny
export let LATENCY_THRESHOLD=0.1;
// threshold fro avaialbility
export let AVAILIBILITY_THRESHOLD=4;