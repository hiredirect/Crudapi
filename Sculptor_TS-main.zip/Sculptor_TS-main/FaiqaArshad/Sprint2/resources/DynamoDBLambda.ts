import { DynamoDBManipulateData } from "./DynamoDBManipulateData";
exports.handler = async function (event: any) {
    // parsing json file to retrieve information when alarm trigger
    const msgObj = JSON.parse(event.Records[0].Sns.Message);
    // getting table name
    const tableName = process.env.table;
    // retrive msg id from event
    const msgId = event.Records[0].Sns.MessageId;
// metric name by which alatrm trigger
    const metricName = msgObj.Trigger.MetricName;
    // web resources which breaches threshold
    const url = msgObj.Trigger.Dimensions[0].value
    // namespace
    const nameSpace = msgObj.Trigger.Namespace;
    
    // instance of DynamoDMManiuplate data
    const dbTable = new DynamoDBManipulateData();
    if (event.Records) {
        const res = dbTable.addData(tableName, msgId,  metricName, nameSpace, url);
    }

}